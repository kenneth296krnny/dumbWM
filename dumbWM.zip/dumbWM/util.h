#ifndef UTIL_H
#define UTIL_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>

#define LOG(...) do { fprintf(stderr, "[dumbwm] "); fprintf(stderr, __VA_ARGS__); fprintf(stderr, "\n"); } while(0)
#define WARN(...) do { fprintf(stderr, "[dumbwm WARN] "); fprintf(stderr, __VA_ARGS__); fprintf(stderr, "\n"); } while(0)

void  die(const char *fmt, ...);
void *ecalloc(size_t nmemb, size_t size);
char *estrdup(const char *s);

#endif /* UTIL_H */
