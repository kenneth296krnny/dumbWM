#include "util.h"

void die(const char *fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    fprintf(stderr, "[dumbwm FATAL] ");
    vfprintf(stderr, fmt, ap);
    fprintf(stderr, "\n");
    va_end(ap);
    exit(1);
}

void *ecalloc(size_t nmemb, size_t size) {
    void *p = calloc(nmemb, size);
    if (!p)
        die("calloc failed");
    return p;
}

char *estrdup(const char *s) {
    char *p = strdup(s);
    if (!p)
        die("strdup failed");
    return p;
}
