#include "tray.h"
#include "wm.h"
#include "util.h"
#include <X11/Xutil.h>
#include <X11/Xatom.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#define SYSTEM_TRAY_REQUEST_DOCK   0
#define SYSTEM_TRAY_BEGIN_MESSAGE  1
#define SYSTEM_TRAY_CANCEL_MESSAGE 2

#define XEMBED_MAPPED              (1 << 0)
#define XEMBED_EMBEDDED_NOTIFY     0

static Atom net_system_tray_s = None;
static Atom net_system_tray_opcode = None;
static Atom net_system_tray_orientation = None;
static Atom net_system_tray_visual = None;
static Atom xembed = None;
static Atom xembed_info = None;
static Atom manager = None;

static Window tray_win = None;
static TrayIcon *icons = NULL;
static int icon_size = 24;

void tray_init(WM *wm, Window parent_win) {
    if (tray_win != None) return;

    net_system_tray_s = XInternAtom(wm->dpy, "_NET_SYSTEM_TRAY_S0", False);
    net_system_tray_opcode = XInternAtom(wm->dpy, "_NET_SYSTEM_TRAY_OPCODE", False);
    net_system_tray_orientation = XInternAtom(wm->dpy, "_NET_SYSTEM_TRAY_ORIENTATION", False);
    net_system_tray_visual = XInternAtom(wm->dpy, "_NET_SYSTEM_TRAY_VISUAL", False);
    xembed = XInternAtom(wm->dpy, "_XEMBED", False);
    xembed_info = XInternAtom(wm->dpy, "_XEMBED_INFO", False);
    manager = XInternAtom(wm->dpy, "MANAGER", False);

    XSetWindowAttributes wa;
    wa.override_redirect = True;
    wa.background_pixel = BlackPixel(wm->dpy, wm->screen);
    wa.event_mask = SubstructureNotifyMask | ExposureMask;

    tray_win = XCreateWindow(wm->dpy, parent_win, -100, -100, 1, 1, 0,
                             CopyFromParent, InputOutput, CopyFromParent,
                             CWOverrideRedirect | CWBackPixel | CWEventMask, &wa);

    /* Set orientation to horizontal (0) */
    int orientation = 0;
    XChangeProperty(wm->dpy, tray_win, net_system_tray_orientation,
                    XA_CARDINAL, 32, PropModeReplace, (unsigned char *)&orientation, 1);

    VisualID visual_id = XVisualIDFromVisual(DefaultVisual(wm->dpy, wm->screen));
    XChangeProperty(wm->dpy, tray_win, net_system_tray_visual,
                    XA_VISUALID, 32, PropModeReplace, (unsigned char *)&visual_id, 1);

    XSetSelectionOwner(wm->dpy, net_system_tray_s, tray_win, CurrentTime);
    if (XGetSelectionOwner(wm->dpy, net_system_tray_s) != tray_win) {
        WARN("Could not acquire _NET_SYSTEM_TRAY_S0 selection");
        return;
    }

    /* Send MANAGER client message to notify clients */
    XClientMessageEvent ev;
    memset(&ev, 0, sizeof(ev));
    ev.type = ClientMessage;
    ev.window = wm->root;
    ev.message_type = manager;
    ev.format = 32;
    ev.data.l[0] = CurrentTime;
    ev.data.l[1] = net_system_tray_s;
    ev.data.l[2] = tray_win;
    ev.data.l[3] = 0;
    ev.data.l[4] = 0;
    XSendEvent(wm->dpy, wm->root, False, StructureNotifyMask, (XEvent *)&ev);

    XMapWindow(wm->dpy, tray_win);
    LOG("System tray initialized");
}

static void send_xembed_message(WM *wm, Window target, long message, long detail, long data1, long data2) {
    XEvent ev;
    memset(&ev, 0, sizeof(ev));
    ev.xclient.type = ClientMessage;
    ev.xclient.window = target;
    ev.xclient.message_type = xembed;
    ev.xclient.format = 32;
    ev.xclient.data.l[0] = CurrentTime;
    ev.xclient.data.l[1] = message;
    ev.xclient.data.l[2] = detail;
    ev.xclient.data.l[3] = data1;
    ev.xclient.data.l[4] = data2;
    XSendEvent(wm->dpy, target, False, NoEventMask, &ev);
    XSync(wm->dpy, False);
}

static void get_xembed_info(WM *wm, Window win, unsigned long *flags) {
    Atom actual_type;
    int actual_format;
    unsigned long nitems, bytes_after;
    unsigned char *data = NULL;
    
    *flags = XEMBED_MAPPED; /* Default */

    if (XGetWindowProperty(wm->dpy, win, xembed_info, 0, 2, False,
                           xembed_info, &actual_type, &actual_format,
                           &nitems, &bytes_after, &data) == Success && data) {
        if (actual_type == xembed_info && actual_format == 32 && nitems >= 2) {
            *flags = ((unsigned long *)data)[1];
        }
        XFree(data);
    }
}

static void tray_icon_add(WM *wm, Window win) {
    /* Check if already added */
    for (TrayIcon *i = icons; i; i = i->next) {
        if (i->win == win) return;
    }

    TrayIcon *ti = calloc(1, sizeof(TrayIcon));
    ti->win = win;
    ti->w = icon_size;
    ti->h = icon_size;

    XSelectInput(wm->dpy, win, StructureNotifyMask | PropertyChangeMask);
    XReparentWindow(wm->dpy, win, tray_win, 0, 0);

    /* Get XEMBED info */
    unsigned long flags;
    get_xembed_info(wm, win, &flags);

    ti->next = icons;
    icons = ti;

    /* Tell the client it has been embedded */
    send_xembed_message(wm, win, XEMBED_EMBEDDED_NOTIFY, 0, tray_win, 0);

    if (flags & XEMBED_MAPPED) {
        XMapWindow(wm->dpy, win);
    }

    LOG("Added tray icon: 0x%lx", win);
}

void tray_handle_client_message(WM *wm, XClientMessageEvent *ev) {
    if (ev->message_type == net_system_tray_opcode &&
        ev->data.l[1] == SYSTEM_TRAY_REQUEST_DOCK) {
        Window win = ev->data.l[2];
        tray_icon_add(wm, win);
    }
}

void tray_handle_property_notify(WM *wm, XPropertyEvent *ev) {
    if (ev->atom == xembed_info) {
        for (TrayIcon *ti = icons; ti; ti = ti->next) {
            if (ti->win == ev->window) {
                unsigned long flags;
                get_xembed_info(wm, ev->window, &flags);
                if (flags & XEMBED_MAPPED) {
                    XMapWindow(wm->dpy, ev->window);
                } else {
                    XUnmapWindow(wm->dpy, ev->window);
                }
                break;
            }
        }
    }
}

void tray_handle_unmap_destroy(WM *wm, Window win) {
    TrayIcon **p = &icons;
    while (*p) {
        if ((*p)->win == win) {
            TrayIcon *tmp = *p;
            *p = tmp->next;
            free(tmp);
            LOG("Removed tray icon: 0x%lx", win);
            return;
        }
        p = &(*p)->next;
    }
}

void tray_update(WM *wm, int x, int y, int bar_w) {
    if (tray_win == None) return;

    /* Layout icons horizontally */
    int cur_x = 0;
    int cur_y = (bar_w - icon_size) / 2; /* Center in the bar thickness if vertical */
    
    /* Determine if bar is horizontal or vertical */
    int is_horiz = (wm->cfg->bar_position == 2 || wm->cfg->bar_position == 3);
    
    for (TrayIcon *ti = icons; ti; ti = ti->next) {
        if (is_horiz) {
            XMoveResizeWindow(wm->dpy, ti->win, cur_x, (wm->cfg->bar_width - icon_size) / 2, icon_size, icon_size);
            cur_x += icon_size + 4;
        } else {
            XMoveResizeWindow(wm->dpy, ti->win, (wm->cfg->bar_width - icon_size) / 2, cur_x, icon_size, icon_size);
            cur_x += icon_size + 4;
        }
    }

    int tw = is_horiz ? cur_x : wm->cfg->bar_width;
    int th = is_horiz ? wm->cfg->bar_width : cur_x;
    
    if (cur_x == 0) {
        /* No icons */
        tw = 1; th = 1; x = -100; y = -100;
    } else {
        /* Adjust x/y based on bar position to be at the trailing end */
        if (is_horiz) {
            x = wm->screen_w - tw - 10;
        } else {
            y = wm->screen_h - th - 120; // Above NM/Clock
            x = 0;
        }
    }

    XMoveResizeWindow(wm->dpy, tray_win, x, y, tw, th);
}

void tray_cleanup(WM *wm) {
    if (tray_win != None) {
        XDestroyWindow(wm->dpy, tray_win);
        tray_win = None;
    }
    while (icons) {
        TrayIcon *tmp = icons;
        icons = icons->next;
        free(tmp);
    }
}
