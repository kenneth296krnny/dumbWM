#ifndef CONFIG_H
#define CONFIG_H

#define MAX_WORKSPACES 9
#define MAX_KEYBINDS   64
#define MAX_KEY_LEN    64
#define MAX_VAL_LEN    256
#define MAX_PATH_LEN   512

typedef struct {
    /* General */
    unsigned int mod_key;       /* X11 modifier mask (Mod4Mask = Super) */
    int          border_width;
    unsigned long focus_color;
    unsigned long unfocus_color;
    int          num_workspaces;

    /* Bar */
    int          bar_enabled;
    int          bar_position;  /* 0 = left, 1 = right, 2 = top, 3 = bottom */
    int          bar_width;
    unsigned long bar_bg;
    unsigned long bar_fg;
    unsigned long bar_accent;
    char         bar_font[MAX_VAL_LEN];
    int          bar_follow_gtk; /* 1 = derive bar colors from GTK theme */

    /* Gaps */
    int          gap_inner;
    int          gap_outer;
    int          smart_gaps;    /* 1 = disable gaps when only 1 window */

    /* Compositor */
    int          compositor_enabled;
    int          corner_radius;

    /* Wallpaper */
    char         wallpaper_path[MAX_PATH_LEN]; /* image path, empty = solid color */
    unsigned long wallpaper_color;             /* fallback solid color */
    char         wallpaper_mode[MAX_KEY_LEN];  /* fill, center, tile */

    /* Keybinds */
    char         term_cmd[MAX_VAL_LEN];
    char         launcher_cmd[MAX_VAL_LEN];
} Config;

/* Parse INI config from file; fills cfg with defaults first, then overrides. */
void config_load(Config *cfg, const char *path);

/* Set defaults for all config values */
void config_defaults(Config *cfg);

/* Parse a hex color string like "#RRGGBB" into an unsigned long pixel value */
unsigned long config_parse_color(const char *hex);

/* Ensure default config exists at path; creates dir + file if missing */
void config_ensure_default(const char *path);

#endif /* CONFIG_H */
