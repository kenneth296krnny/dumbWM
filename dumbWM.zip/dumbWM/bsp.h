#ifndef BSP_H
#define BSP_H

#include <X11/Xlib.h>

typedef enum {
    SPLIT_HORIZONTAL,
    SPLIT_VERTICAL,
    SPLIT_NONE
} SplitDir;

typedef struct Client {
    Window          win;
    int             x, y, w, h;
    float           curr_x, curr_y, curr_w, curr_h;
    int             floating;
    int             workspace;
    struct Client  *next;
    struct Client  *prev;
} Client;

typedef struct BspNode {
    int              x, y, w, h;
    float            split_ratio;
    SplitDir         split_dir;
    struct BspNode  *left;
    struct BspNode  *right;
    struct BspNode  *parent;
    Client          *client;  /* non-NULL only for leaf nodes */
} BspNode;

/* Tree operations */
BspNode *bsp_create_node(int x, int y, int w, int h);
void     bsp_free(BspNode *node);
BspNode *bsp_insert(BspNode *root, Client *c, int depth);
BspNode *bsp_remove(BspNode *root, Client *c);
BspNode *bsp_find(BspNode *root, Client *c);
void     bsp_apply_layout(BspNode *node, int gap);
int      bsp_count_leaves(BspNode *node);
void     bsp_update_geometry(BspNode *node, int x, int y, int w, int h);

#endif /* BSP_H */
