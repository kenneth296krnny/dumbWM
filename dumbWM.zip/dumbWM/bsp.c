#include "bsp.h"
#include "util.h"

BspNode *bsp_create_node(int x, int y, int w, int h) {
    BspNode *n = ecalloc(1, sizeof(BspNode));
    n->x = x;
    n->y = y;
    n->w = w;
    n->h = h;
    n->split_ratio = 0.5f;
    n->split_dir = SPLIT_NONE;
    n->left = NULL;
    n->right = NULL;
    n->parent = NULL;
    n->client = NULL;
    return n;
}

void bsp_free(BspNode *node) {
    if (!node) return;
    bsp_free(node->left);
    bsp_free(node->right);
    free(node);
}

/* Find the first empty leaf, or the leaf with the fewest depth to split */
static BspNode *find_insert_leaf(BspNode *node) {
    if (!node) return NULL;
    /* Leaf node */
    if (!node->left && !node->right)
        return node;
    /* Prefer the side with fewer leaves */
    int lc = bsp_count_leaves(node->left);
    int rc = bsp_count_leaves(node->right);
    if (lc <= rc)
        return find_insert_leaf(node->left);
    else
        return find_insert_leaf(node->right);
}

static int node_depth(BspNode *node) {
    int d = 0;
    while (node->parent) {
        d++;
        node = node->parent;
    }
    return d;
}

BspNode *bsp_insert(BspNode *root, Client *c, int depth) {
    (void)depth;
    if (!root) {
        root = bsp_create_node(0, 0, 0, 0);
        root->client = c;
        return root;
    }

    /* If root is a leaf with no client, just place here */
    if (!root->left && !root->right && !root->client) {
        root->client = c;
        return root;
    }

    /* Find best leaf to split */
    BspNode *leaf = find_insert_leaf(root);
    if (!leaf) return root;

    int d = node_depth(leaf);
    /* Alternate split direction based on depth */
    SplitDir dir = (d % 2 == 0) ? SPLIT_HORIZONTAL : SPLIT_VERTICAL;
    /* Prefer splitting along the longer axis */
    if (leaf->w > leaf->h)
        dir = SPLIT_HORIZONTAL;
    else if (leaf->h > leaf->w)
        dir = SPLIT_VERTICAL;

    leaf->split_dir = dir;
    leaf->split_ratio = 0.5f;

    /* Create two children */
    BspNode *left  = bsp_create_node(0, 0, 0, 0);
    BspNode *right = bsp_create_node(0, 0, 0, 0);
    left->parent = leaf;
    right->parent = leaf;

    /* Existing client goes to left child, new client to right */
    left->client = leaf->client;
    right->client = c;
    leaf->client = NULL;

    leaf->left  = left;
    leaf->right = right;

    return root;
}

BspNode *bsp_find(BspNode *root, Client *c) {
    if (!root) return NULL;
    if (root->client == c) return root;
    BspNode *found = bsp_find(root->left, c);
    if (found) return found;
    return bsp_find(root->right, c);
}

BspNode *bsp_remove(BspNode *root, Client *c) {
    BspNode *node = bsp_find(root, c);
    if (!node) return root;

    /* If this is the root leaf */
    if (!node->parent) {
        node->client = NULL;
        bsp_free(node);
        return NULL;
    }

    BspNode *parent = node->parent;
    BspNode *sibling = (parent->left == node) ? parent->right : parent->left;

    /* Replace parent with sibling */
    if (parent->parent) {
        sibling->parent = parent->parent;
        if (parent->parent->left == parent)
            parent->parent->left = sibling;
        else
            parent->parent->right = sibling;
    } else {
        /* Parent was root */
        sibling->parent = NULL;
        root = sibling;
    }

    /* Free the removed node and the now-empty parent */
    node->left = NULL;
    node->right = NULL;
    parent->left = NULL;
    parent->right = NULL;
    free(node);
    free(parent);

    return root;
}

int bsp_count_leaves(BspNode *node) {
    if (!node) return 0;
    if (!node->left && !node->right) return 1;
    return bsp_count_leaves(node->left) + bsp_count_leaves(node->right);
}

void bsp_update_geometry(BspNode *node, int x, int y, int w, int h) {
    if (!node) return;
    node->x = x;
    node->y = y;
    node->w = w;
    node->h = h;

    if (node->split_dir == SPLIT_HORIZONTAL && node->left && node->right) {
        int lw = (int)(w * node->split_ratio);
        bsp_update_geometry(node->left,  x,       y, lw,     h);
        bsp_update_geometry(node->right, x + lw,  y, w - lw, h);
    } else if (node->split_dir == SPLIT_VERTICAL && node->left && node->right) {
        int lh = (int)(h * node->split_ratio);
        bsp_update_geometry(node->left,  x, y,       w, lh);
        bsp_update_geometry(node->right, x, y + lh,  w, h - lh);
    }
}

void bsp_apply_layout(BspNode *node, int gap) {
    if (!node) return;

    if (!node->left && !node->right && node->client) {
        /* Leaf with client — set client geometry with gaps */
        node->client->x = node->x + gap;
        node->client->y = node->y + gap;
        node->client->w = node->w - 2 * gap;
        node->client->h = node->h - 2 * gap;
        if (node->client->w < 1) node->client->w = 1;
        if (node->client->h < 1) node->client->h = 1;
        return;
    }

    bsp_apply_layout(node->left, gap);
    bsp_apply_layout(node->right, gap);
}
