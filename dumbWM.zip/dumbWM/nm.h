#ifndef NM_H
#define NM_H

typedef enum {
    NM_DISCONNECTED,
    NM_CONNECTED_WIFI,
    NM_CONNECTED_WIRED,
    NM_UNKNOWN
} NmConnState;

typedef struct {
    NmConnState state;
    char        ssid[128];
    int         signal_strength; /* 0-100 */
} NmState;

/* Initialize NM monitoring (optional D-Bus connection) */
int  nm_init(void);

/* Poll current state (cached, updated periodically) */
void nm_get_state(NmState *out);

/* Update state by querying NM via D-Bus */
void nm_poll(void);

/* Cleanup */
void nm_cleanup(void);

#endif /* NM_H */
