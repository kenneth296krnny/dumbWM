#ifndef LAUNCHER_H
#define LAUNCHER_H

#include "wm.h"

/* Initialize launcher subsystem */
void launcher_init(WM *wm);

/* Toggle the launcher popup */
void launcher_toggle(WM *wm);

/* Handle events for the launcher window */
int  launcher_handle_event(WM *wm, void *event);

/* Cleanup */
void launcher_destroy(WM *wm);

#endif /* LAUNCHER_H */
