#include "bar.h"
#include "wm.h"
#include "nm.h"
#include "launcher.h"
#include "util.h"
#include "tray.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <time.h>
#include <cairo/cairo.h>
#include <cairo/cairo-xlib.h>
#include <librsvg/rsvg.h>

/*
 * Bar — Cairo-rendered sidebar with icon theme support
 *
 * Uses cairo-xlib for anti-aliased rendering and librsvg
 * for loading SVG icons from the active icon theme.
 * When follow_gtk is enabled, colors are derived from the
 * active GTK theme (like Cinnamon's panel).
 */

/* ─── Colors (mutable — overridden by GTK follow mode) ───── */
static double col_bar_bg[3]   = {0.114, 0.114, 0.114};  /* #1d1d1d */
static double col_tile_bg[3]  = {0.176, 0.176, 0.176};  /* #2d2d2d */
static double col_accent[3]   = {0.000, 0.471, 0.831};  /* #0078D4 */
static double col_text[3]     = {1.000, 1.000, 1.000};  /* #FFFFFF */
static double col_text_dim[3] = {0.533, 0.533, 0.533};  /* #888888 */
static double col_divider[3]  = {0.227, 0.227, 0.227};  /* #3a3a3a */

static Bar g_bar;
static int g_bar_initialized = 0;

/* ─── Icon theme paths ───────────────────────────────────── */
static char g_icon_theme[256] = "Qogir";

/* Cached SVG icon surfaces */
static cairo_surface_t *icon_grid    = NULL;
static cairo_surface_t *icon_wifi    = NULL;
static cairo_surface_t *icon_wired   = NULL;
static cairo_surface_t *icon_nonet   = NULL;
static cairo_surface_t *icon_settings = NULL;

/* ─── Color helpers ──────────────────────────────────────── */

static void hex_to_rgb(unsigned long hex, double *r, double *g, double *b) {
    *r = ((hex >> 16) & 0xFF) / 255.0;
    *g = ((hex >>  8) & 0xFF) / 255.0;
    *b = ((hex      ) & 0xFF) / 255.0;
}

static unsigned long parse_css_color(const char *val) {
    unsigned int r = 0, g = 0, b = 0;
    if (val[0] == '#' && strlen(val) >= 7) {
        sscanf(val + 1, "%02x%02x%02x", &r, &g, &b);
    } else if (strncmp(val, "rgb(", 4) == 0) {
        sscanf(val + 4, "%u,%u,%u", &r, &g, &b);
    }
    return (r << 16) | (g << 8) | b;
}

/* ─── Icon Loading ───────────────────────────────────────── */

static cairo_surface_t *load_svg_icon(const char *icon_name, int size) {
    /* Try multiple paths for the icon theme */
    char paths[6][512];
    int np = 0;
    const char *home = getenv("HOME");

    /* Try exact size directory first, then scalable */
    snprintf(paths[np++], 512, "/usr/share/icons/%s/%d/panel/%s.svg", g_icon_theme, size, icon_name);
    snprintf(paths[np++], 512, "/usr/share/icons/%s/%d/devices/%s.svg", g_icon_theme, size, icon_name);
    snprintf(paths[np++], 512, "/usr/share/icons/%s/%d/actions/%s.svg", g_icon_theme, size, icon_name);
    snprintf(paths[np++], 512, "/usr/share/icons/%s/scalable/apps/%s.svg", g_icon_theme, icon_name);
    snprintf(paths[np++], 512, "/usr/share/icons/%s/scalable/devices/%s.svg", g_icon_theme, icon_name);
    if (home)
        snprintf(paths[np++], 512, "%s/.local/share/icons/%s/scalable/apps/%s.svg", home, g_icon_theme, icon_name);

    for (int i = 0; i < np; i++) {
        FILE *f = fopen(paths[i], "r");
        if (!f) continue;
        fclose(f);

        GError *err = NULL;
        RsvgHandle *svg = rsvg_handle_new_from_file(paths[i], &err);
        if (!svg) {
            if (err) g_error_free(err);
            continue;
        }

        /* Render to a cairo image surface at the requested size */
        cairo_surface_t *surf = cairo_image_surface_create(CAIRO_FORMAT_ARGB32, size, size);
        cairo_t *cr = cairo_create(surf);

        /* Scale SVG to fit */
        RsvgRectangle viewport = { 0, 0, size, size };
        rsvg_handle_render_document(svg, cr, &viewport, NULL);

        cairo_destroy(cr);
        g_object_unref(svg);

        LOG("Loaded icon: %s from %s", icon_name, paths[i]);
        return surf;
    }

    return NULL;  /* Icon not found */
}

static void load_bar_icons(int size) {
    /* Free old icons */
    if (icon_grid)     { cairo_surface_destroy(icon_grid);     icon_grid = NULL; }
    if (icon_wifi)     { cairo_surface_destroy(icon_wifi);     icon_wifi = NULL; }
    if (icon_wired)    { cairo_surface_destroy(icon_wired);    icon_wired = NULL; }
    if (icon_nonet)    { cairo_surface_destroy(icon_nonet);    icon_nonet = NULL; }
    if (icon_settings) { cairo_surface_destroy(icon_settings); icon_settings = NULL; }

    /* Load from icon theme */
    icon_grid     = load_svg_icon("view-app-grid", size);
    icon_wifi     = load_svg_icon("network-wireless-signal-excellent", size);
    if (!icon_wifi)
        icon_wifi = load_svg_icon("network-wireless", size);
    icon_wired    = load_svg_icon("network-wired", size);
    if (!icon_wired)
        icon_wired = load_svg_icon("network-wired-activated", size);
    icon_nonet    = load_svg_icon("network-offline", size);
    if (!icon_nonet)
        icon_nonet = load_svg_icon("network-disconnect", size);
    icon_settings = load_svg_icon("preferences-system", size);
}

/* ─── GTK Theme Color Parsing ────────────────────────────── */

static void bar_load_gtk_colors(void) {
    char settings_path[512];
    char theme_name[256] = "";
    const char *home = getenv("HOME");
    if (!home) return;

    snprintf(settings_path, sizeof(settings_path),
             "%s/.config/gtk-3.0/settings.ini", home);

    FILE *f = fopen(settings_path, "r");
    if (!f) return;

    char line[1024];
    while (fgets(line, sizeof(line), f)) {
        char *s = line;
        while (*s == ' ' || *s == '\t') s++;
        if (strncmp(s, "gtk-theme-name", 14) == 0) {
            char *eq = strchr(s, '=');
            if (eq) {
                eq++;
                while (*eq == ' ' || *eq == '\t') eq++;
                char *end = eq + strlen(eq) - 1;
                while (end > eq && (*end == '\n' || *end == '\r' || *end == ' '))
                    *end-- = '\0';
                strncpy(theme_name, eq, sizeof(theme_name) - 1);
            }
        }
        /* Also read icon theme name */
        if (strncmp(s, "gtk-icon-theme-name", 19) == 0) {
            char *eq = strchr(s, '=');
            if (eq) {
                eq++;
                while (*eq == ' ' || *eq == '\t') eq++;
                char *end = eq + strlen(eq) - 1;
                while (end > eq && (*end == '\n' || *end == '\r' || *end == ' '))
                    *end-- = '\0';
                strncpy(g_icon_theme, eq, sizeof(g_icon_theme) - 1);
            }
        }
    }
    fclose(f);

    if (theme_name[0] == '\0') return;

    /* Parse gtk.css / gtk-dark.css for @define-color */
    char css_paths[4][512];
    int npaths = 0;
    snprintf(css_paths[npaths++], 512,
             "%s/.themes/%s/gtk-3.0/gtk-dark.css", home, theme_name);
    snprintf(css_paths[npaths++], 512,
             "/usr/share/themes/%s/gtk-3.0/gtk-dark.css", theme_name);
    snprintf(css_paths[npaths++], 512,
             "%s/.themes/%s/gtk-3.0/gtk.css", home, theme_name);
    snprintf(css_paths[npaths++], 512,
             "/usr/share/themes/%s/gtk-3.0/gtk.css", theme_name);

    for (int p = 0; p < npaths; p++) {
        f = fopen(css_paths[p], "r");
        if (!f) continue;

        int got_bg = 0;
        while (fgets(line, sizeof(line), f)) {
            char *s = line;
            while (*s == ' ' || *s == '\t') s++;
            if (strncmp(s, "@define-color", 13) != 0) continue;

            char name[128], value[128];
            if (sscanf(s, "@define-color %127s %127[^;]", name, value) == 2) {
                unsigned long c = parse_css_color(value);
                if (strcmp(name, "theme_bg_color") == 0 || strcmp(name, "bg_color") == 0) {
                    hex_to_rgb(c, &col_bar_bg[0], &col_bar_bg[1], &col_bar_bg[2]);
                    /* Derive tile_bg and divider from bg */
                    double f = 1.15;
                    col_tile_bg[0] = col_bar_bg[0] * f;
                    col_tile_bg[1] = col_bar_bg[1] * f;
                    col_tile_bg[2] = col_bar_bg[2] * f;
                    f = 1.4;
                    col_divider[0] = col_bar_bg[0] * f;
                    col_divider[1] = col_bar_bg[1] * f;
                    col_divider[2] = col_bar_bg[2] * f;
                    got_bg = 1;
                } else if (strcmp(name, "theme_fg_color") == 0 || strcmp(name, "fg_color") == 0) {
                    hex_to_rgb(c, &col_text[0], &col_text[1], &col_text[2]);
                    col_text_dim[0] = col_text[0] * 0.5;
                    col_text_dim[1] = col_text[1] * 0.5;
                    col_text_dim[2] = col_text[2] * 0.5;
                } else if (strcmp(name, "theme_selected_bg_color") == 0 ||
                           strcmp(name, "selected_bg_color") == 0 ||
                           strcmp(name, "accent_color") == 0) {
                    hex_to_rgb(c, &col_accent[0], &col_accent[1], &col_accent[2]);
                }
            }
        }
        fclose(f);
        if (got_bg) break;
    }

    LOG("Bar: loaded GTK theme colors from '%s', icon theme '%s'", theme_name, g_icon_theme);
}

/* ─── Cairo Drawing Helpers ──────────────────────────────── */

static void cr_rounded_rect(cairo_t *cr, double x, double y, double w, double h, double r) {
    cairo_new_sub_path(cr);
    cairo_arc(cr, x + w - r, y + r,     r, -G_PI/2, 0);
    cairo_arc(cr, x + w - r, y + h - r, r,  0,       G_PI/2);
    cairo_arc(cr, x + r,     y + h - r, r,  G_PI/2,  G_PI);
    cairo_arc(cr, x + r,     y + r,     r,  G_PI,    3*G_PI/2);
    cairo_close_path(cr);
}

static void cr_text_centered(cairo_t *cr, double x, double y, double w, double h,
                              const char *text, double font_size) {
    cairo_set_font_size(cr, font_size);
    cairo_text_extents_t ext;
    cairo_text_extents(cr, text, &ext);
    double tx = x + (w - ext.width) / 2 - ext.x_bearing;
    double ty = y + (h - ext.height) / 2 - ext.y_bearing;
    cairo_move_to(cr, tx, ty);
    cairo_show_text(cr, text);
}

static void cr_draw_icon(cairo_t *cr, cairo_surface_t *icon,
                          double x, double y, double w, double h, int icon_size) {
    if (!icon) return;
    cairo_save(cr);
    double ox = x + (w - icon_size) / 2;
    double oy = y + (h - icon_size) / 2;
    cairo_set_source_surface(cr, icon, ox, oy);
    cairo_paint(cr);
    cairo_restore(cr);
}

/* ─── Tile Drawing ───────────────────────────────────────── */

static void draw_start_tile(cairo_t *cr, int bw, int tile_h) {
    int margin = 4;
    double tw = bw - 2 * margin;
    double r = 6;

    /* Accent colored rounded tile */
    cairo_set_source_rgb(cr, col_accent[0], col_accent[1], col_accent[2]);
    cr_rounded_rect(cr, margin, margin, tw, tile_h - 2 * margin, r);
    cairo_fill(cr);

    /* Draw app grid icon or fallback grid */
    if (icon_grid) {
        cr_draw_icon(cr, icon_grid, 0, 0, bw, tile_h, 22);
    } else {
        /* Fallback: 2x2 grid squares */
        cairo_set_source_rgb(cr, col_text[0], col_text[1], col_text[2]);
        int cx = bw / 2, cy = tile_h / 2;
        int sz = 6, gap = 3;
        cairo_rectangle(cr, cx - sz - gap/2, cy - sz - gap/2, sz, sz);
        cairo_rectangle(cr, cx + gap/2,      cy - sz - gap/2, sz, sz);
        cairo_rectangle(cr, cx - sz - gap/2, cy + gap/2,      sz, sz);
        cairo_rectangle(cr, cx + gap/2,      cy + gap/2,      sz, sz);
        cairo_fill(cr);
    }
}

static void draw_workspace_tiles(cairo_t *cr, int bw, int start_y, int tile_h,
                                  int current_ws, int num_ws) {
    int margin = 4;
    double tw = bw - 2 * margin;
    double r = 6;

    for (int i = 0; i < num_ws; i++) {
        int y = start_y + i * tile_h;

        if (i == current_ws) {
            /* Active: accent rounded tile */
            cairo_set_source_rgb(cr, col_accent[0], col_accent[1], col_accent[2]);
            cr_rounded_rect(cr, margin, y + 1, tw, tile_h - 2, r);
            cairo_fill(cr);

            /* Left indicator bar (rounded) */
            cairo_set_source_rgb(cr, col_text[0], col_text[1], col_text[2]);
            cr_rounded_rect(cr, 0, y + 6, 3, tile_h - 12, 1.5);
            cairo_fill(cr);

            /* Number in white */
            cairo_set_source_rgb(cr, col_text[0], col_text[1], col_text[2]);
        } else {
            /* Inactive: dark rounded tile */
            cairo_set_source_rgb(cr, col_tile_bg[0], col_tile_bg[1], col_tile_bg[2]);
            cr_rounded_rect(cr, margin, y + 1, tw, tile_h - 2, r);
            cairo_fill(cr);

            /* Number in dim */
            cairo_set_source_rgb(cr, col_text_dim[0], col_text_dim[1], col_text_dim[2]);
        }

        char label[8];
        snprintf(label, sizeof(label), "%d", i + 1);
        cr_text_centered(cr, 0, y, bw, tile_h, label, 13);
    }
}

static void draw_nm_tile(cairo_t *cr, int bw, int y, int tile_h, NmState *nm) {
    int margin = 4;
    double tw = bw - 2 * margin;
    double r = 6;

    /* Tile background */
    cairo_set_source_rgb(cr, col_tile_bg[0], col_tile_bg[1], col_tile_bg[2]);
    cr_rounded_rect(cr, margin, y + 1, tw, tile_h - 2, r);
    cairo_fill(cr);

    /* Network icon or text fallback */
    cairo_surface_t *icon = NULL;
    const char *fallback = "?";
    double icon_r = 0.5, icon_g = 0.5, icon_b = 0.5;

    switch (nm->state) {
        case NM_CONNECTED_WIFI:
            icon = icon_wifi;
            fallback = "W";
            icon_r = 0.0; icon_g = 0.698; icon_b = 0.580;  /* teal */
            break;
        case NM_CONNECTED_WIRED:
            icon = icon_wired;
            fallback = "E";
            icon_r = 0.0; icon_g = 0.698; icon_b = 0.580;
            break;
        case NM_DISCONNECTED:
            icon = icon_nonet;
            fallback = "X";
            icon_r = 0.910; icon_g = 0.067; icon_b = 0.137;  /* red */
            break;
        default:
            fallback = "?";
            break;
    }

    if (icon) {
        cr_draw_icon(cr, icon, 0, y, bw, tile_h, 20);
    } else {
        cairo_set_source_rgb(cr, icon_r, icon_g, icon_b);
        cr_text_centered(cr, 0, y, bw, tile_h, fallback, 14);
    }
}

static void draw_clock_tile(cairo_t *cr, int bw, int y, int tile_h) {
    time_t now = time(NULL);
    struct tm *tm = localtime(&now);
    char timebuf[16];

    /* Hours */
    snprintf(timebuf, sizeof(timebuf), "%02d", tm->tm_hour);
    cairo_set_source_rgb(cr, col_accent[0], col_accent[1], col_accent[2]);
    cr_text_centered(cr, 0, y, bw, tile_h / 3, timebuf, 14);

    /* Divider dot */
    cairo_set_source_rgb(cr, col_text_dim[0], col_text_dim[1], col_text_dim[2]);
    int cx = bw / 2;
    int cy_dot = y + tile_h / 3 + 2;
    cairo_arc(cr, cx, cy_dot + 1.5, 1.5, 0, 2 * G_PI);
    cairo_fill(cr);

    /* Minutes */
    snprintf(timebuf, sizeof(timebuf), "%02d", tm->tm_min);
    cairo_set_source_rgb(cr, col_text[0], col_text[1], col_text[2]);
    cr_text_centered(cr, 0, y + tile_h / 3 + 7, bw, tile_h / 3, timebuf, 14);

    /* Date */
    snprintf(timebuf, sizeof(timebuf), "%d/%d", tm->tm_mon + 1, tm->tm_mday);
    cairo_set_source_rgb(cr, col_text_dim[0], col_text_dim[1], col_text_dim[2]);
    cr_text_centered(cr, 0, y + 2 * tile_h / 3 + 4, bw, tile_h / 3 - 4, timebuf, 10);
}

/* ─── Bar Lifecycle ──────────────────────────────────────── */

void bar_init(Bar *bar, WM *wm) {
    Config *cfg = wm->cfg;
    if (!cfg->bar_enabled) return;

    /* Load GTK theme colors + icon theme name if follow mode is on */
    if (cfg->bar_follow_gtk) {
        bar_load_gtk_colors();
    } else {
        /* Read icon theme name from gsettings even if not following GTK colors */
        const char *home = getenv("HOME");
        if (home) {
            char path[512];
            snprintf(path, sizeof(path), "%s/.config/gtk-3.0/settings.ini", home);
            FILE *f = fopen(path, "r");
            if (f) {
                char line[1024];
                while (fgets(line, sizeof(line), f)) {
                    char *s = line;
                    while (*s == ' ' || *s == '\t') s++;
                    if (strncmp(s, "gtk-icon-theme-name", 19) == 0) {
                        char *eq = strchr(s, '=');
                        if (eq) {
                            eq++;
                            while (*eq == ' ' || *eq == '\t') eq++;
                            char *end = eq + strlen(eq) - 1;
                            while (end > eq && (*end == '\n' || *end == '\r' || *end == ' '))
                                *end-- = '\0';
                            strncpy(g_icon_theme, eq, sizeof(g_icon_theme) - 1);
                        }
                    }
                }
                fclose(f);
            }
        }
    }

    /* Apply config accent color */
    hex_to_rgb(cfg->bar_accent, &col_accent[0], &col_accent[1], &col_accent[2]);

    /* Load icons from the icon theme */
    load_bar_icons(24);

    switch (cfg->bar_position) {
        case 0: bar->x = 0; bar->y = 0;
                bar->w = cfg->bar_width; bar->h = wm->screen_h; break;
        case 1: bar->x = wm->screen_w - cfg->bar_width; bar->y = 0;
                bar->w = cfg->bar_width; bar->h = wm->screen_h; break;
        case 2: bar->x = 0; bar->y = 0;
                bar->w = wm->screen_w; bar->h = cfg->bar_width; break;
        case 3: bar->x = 0; bar->y = wm->screen_h - cfg->bar_width;
                bar->w = wm->screen_w; bar->h = cfg->bar_width; break;
    }

    XSetWindowAttributes wa;
    wa.override_redirect = True;
    wa.background_pixel  = BlackPixel(wm->dpy, wm->screen);
    wa.event_mask        = ExposureMask | ButtonPressMask;

    bar->win = XCreateWindow(
        wm->dpy, wm->root,
        bar->x, bar->y, bar->w, bar->h,
        0, DefaultDepth(wm->dpy, wm->screen), InputOutput,
        DefaultVisual(wm->dpy, wm->screen),
        CWOverrideRedirect | CWBackPixel | CWEventMask,
        &wa
    );

    bar->gc = XCreateGC(wm->dpy, bar->win, 0, NULL);
    bar->buffer = XCreatePixmap(wm->dpy, bar->win, bar->w, bar->h,
                                 DefaultDepth(wm->dpy, wm->screen));

    /* Load font for fallback text rendering */
    bar->font = XLoadQueryFont(wm->dpy, "-*-helvetica-bold-r-*-*-12-*-*-*-*-*-*-*");
    if (!bar->font)
        bar->font = XLoadQueryFont(wm->dpy, "-misc-fixed-bold-r-normal--13-*-*-*-*-*-*-*");
    if (!bar->font)
        bar->font = XLoadQueryFont(wm->dpy, "fixed");

    XMapRaised(wm->dpy, bar->win);

    g_bar = *bar;
    g_bar_initialized = 1;

    tray_init(wm, bar->win);

    LOG("Bar initialized at %dx%d+%d+%d (icon theme: %s)",
        bar->w, bar->h, bar->x, bar->y, g_icon_theme);
}

void bar_update(WM *wm) {
    if (!g_bar_initialized || !wm->cfg->bar_enabled) return;

    Bar *bar = &g_bar;
    Display *dpy = wm->dpy;
    Config *cfg = wm->cfg;

    int bw = bar->w;
    int bh = bar->h;
    int tile_h = 40;

    /* Create cairo surface for the pixmap buffer */
    cairo_surface_t *surf = cairo_xlib_surface_create(
        dpy, bar->buffer,
        DefaultVisual(dpy, wm->screen),
        bw, bh
    );
    cairo_t *cr = cairo_create(surf);

    /* Select a nice font */
    cairo_select_font_face(cr, "Sans", CAIRO_FONT_SLANT_NORMAL, CAIRO_FONT_WEIGHT_BOLD);

    /* ── Clear with background ── */
    cairo_set_source_rgb(cr, col_bar_bg[0], col_bar_bg[1], col_bar_bg[2]);
    cairo_paint(cr);

    /* ── Start Menu tile (top) ── */
    int start_h = tile_h + 8;
    draw_start_tile(cr, bw, start_h);

    /* ── Thin divider ── */
    cairo_set_source_rgb(cr, col_divider[0], col_divider[1], col_divider[2]);
    cairo_set_line_width(cr, 1);
    cairo_move_to(cr, 6, start_h);
    cairo_line_to(cr, bw - 6, start_h);
    cairo_stroke(cr);

    /* ── Workspace tiles ── */
    int ws_start = start_h + 4;
    draw_workspace_tiles(cr, bw, ws_start, tile_h, wm->current_ws, cfg->num_workspaces);

    /* ── Bottom section ── */
    int bottom_h = tile_h + 60;
    int bottom_start = bh - bottom_h;

    /* Divider above bottom section */
    cairo_set_source_rgb(cr, col_divider[0], col_divider[1], col_divider[2]);
    cairo_move_to(cr, 6, bottom_start);
    cairo_line_to(cr, bw - 6, bottom_start);
    cairo_stroke(cr);

    /* NM status tile */
    NmState nm;
    nm_get_state(&nm);
    draw_nm_tile(cr, bw, bottom_start + 4, tile_h, &nm);

    /* Clock tile */
    draw_clock_tile(cr, bw, bottom_start + tile_h + 4, 56);

    /* Cleanup cairo */
    cairo_destroy(cr);
    cairo_surface_destroy(surf);

    /* ── Copy buffer to window ── */
    XCopyArea(dpy, bar->buffer, bar->win, bar->gc, 0, 0, bw, bh, 0, 0);
    XFlush(dpy);

    /* Update tray position */
    tray_update(wm, bar->x, bar->y, bw);
}

void bar_handle_click(WM *wm, int x, int y) {
    if (!g_bar_initialized) return;

    Bar *bar = &g_bar;
    Config *cfg = wm->cfg;

    if (x < bar->x || x >= bar->x + bar->w ||
        y < bar->y || y >= bar->y + bar->h)
        return;

    int rel_y = y - bar->y;
    int tile_h = 40;
    int start_h = tile_h + 8;

    /* Start Menu tile */
    if (rel_y < start_h) {
        launcher_toggle(wm);
        return;
    }

    /* Workspace tiles */
    int ws_start = start_h + 4;
    for (int i = 0; i < cfg->num_workspaces; i++) {
        int wy = ws_start + i * tile_h;
        if (rel_y >= wy && rel_y < wy + tile_h) {
            wm_workspace_switch(wm, i);
            return;
        }
    }

    /* Bottom section (NM, clock) */
    int bottom_h = tile_h + 60;
    int bottom_start = bar->h - bottom_h;
    if (rel_y >= bottom_start && rel_y < bottom_start + tile_h) {
        LOG("NM tile clicked");
    }
}

void bar_destroy(Bar *bar, WM *wm) {
    if (!g_bar_initialized) return;
    if (bar->font) XFreeFont(wm->dpy, bar->font);
    XFreePixmap(wm->dpy, bar->buffer);
    XFreeGC(wm->dpy, bar->gc);
    XDestroyWindow(wm->dpy, bar->win);
    g_bar_initialized = 0;

    tray_cleanup(wm);

    /* Free icon surfaces */
    if (icon_grid)     cairo_surface_destroy(icon_grid);
    if (icon_wifi)     cairo_surface_destroy(icon_wifi);
    if (icon_wired)    cairo_surface_destroy(icon_wired);
    if (icon_nonet)    cairo_surface_destroy(icon_nonet);
    if (icon_settings) cairo_surface_destroy(icon_settings);
    icon_grid = icon_wifi = icon_wired = icon_nonet = icon_settings = NULL;
}

void bar_reload_colors(WM *wm) {
    if (!g_bar_initialized || !wm->cfg->bar_enabled) return;

    /* Reset to defaults */
    hex_to_rgb(0x1d1d1d, &col_bar_bg[0],   &col_bar_bg[1],   &col_bar_bg[2]);
    hex_to_rgb(0x2d2d2d, &col_tile_bg[0],  &col_tile_bg[1],  &col_tile_bg[2]);
    hex_to_rgb(0x0078D4, &col_accent[0],   &col_accent[1],   &col_accent[2]);
    hex_to_rgb(0xFFFFFF, &col_text[0],     &col_text[1],     &col_text[2]);
    hex_to_rgb(0x888888, &col_text_dim[0], &col_text_dim[1], &col_text_dim[2]);
    hex_to_rgb(0x3a3a3a, &col_divider[0],  &col_divider[1],  &col_divider[2]);

    /* Apply config accent */
    hex_to_rgb(wm->cfg->bar_accent, &col_accent[0], &col_accent[1], &col_accent[2]);

    /* Override with GTK theme colors if follow mode is on */
    if (wm->cfg->bar_follow_gtk) {
        bar_load_gtk_colors();
    }

    /* Reload icons (icon theme may have changed) */
    load_bar_icons(24);

    LOG("Bar colors reloaded (follow_gtk=%d, icon_theme=%s)",
        wm->cfg->bar_follow_gtk, g_icon_theme);
}
