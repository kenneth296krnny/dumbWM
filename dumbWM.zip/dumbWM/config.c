#include "config.h"
#include "util.h"
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <errno.h>
#include <X11/Xlib.h>

unsigned long config_parse_color(const char *hex) {
    if (!hex || hex[0] != '#' || strlen(hex) < 7)
        return 0x000000;
    unsigned long r, g, b;
    sscanf(hex + 1, "%02lx%02lx%02lx", &r, &g, &b);
    return (r << 16) | (g << 8) | b;
}

void config_defaults(Config *cfg) {
    memset(cfg, 0, sizeof(Config));
    cfg->mod_key        = (1 << 6); /* Mod4Mask = Super */
    cfg->border_width   = 2;
    cfg->focus_color    = config_parse_color("#0078D4");
    cfg->unfocus_color  = config_parse_color("#333333");
    cfg->num_workspaces = 9;

    cfg->bar_enabled    = 1;
    cfg->bar_position   = 0; /* left */
    cfg->bar_width      = 48;
    cfg->bar_bg         = config_parse_color("#1e1e2e");
    cfg->bar_fg         = config_parse_color("#cdd6f4");
    cfg->bar_accent     = config_parse_color("#0078D4");
    strncpy(cfg->bar_font, "fixed", MAX_VAL_LEN - 1);
    cfg->bar_follow_gtk = 0;

    cfg->gap_inner      = 8;
    cfg->gap_outer      = 8;
    cfg->smart_gaps     = 1;

    cfg->compositor_enabled = 1;
    cfg->corner_radius  = 12;

    strncpy(cfg->term_cmd, "xterm", MAX_VAL_LEN - 1);
    strncpy(cfg->launcher_cmd, "", MAX_VAL_LEN - 1);

    cfg->wallpaper_color = config_parse_color("#1a1b26");
    cfg->wallpaper_path[0] = '\0';
    strncpy(cfg->wallpaper_mode, "fill", MAX_KEY_LEN - 1);
}

static char *strip(char *s) {
    while (isspace((unsigned char)*s)) s++;
    char *end = s + strlen(s) - 1;
    while (end > s && isspace((unsigned char)*end)) *end-- = '\0';
    return s;
}

static int parse_position(const char *val) {
    if (strcmp(val, "left") == 0)   return 0;
    if (strcmp(val, "right") == 0)  return 1;
    if (strcmp(val, "top") == 0)    return 2;
    if (strcmp(val, "bottom") == 0) return 3;
    return 0;
}

void config_load(Config *cfg, const char *path) {
    config_defaults(cfg);

    FILE *f = fopen(path, "r");
    if (!f) {
        LOG("Config file not found at %s, using defaults", path);
        return;
    }

    char line[1024];
    char section[128] = "";

    while (fgets(line, sizeof(line), f)) {
        char *s = strip(line);
        if (*s == '\0' || *s == ';' || *s == '#')
            continue;

        /* Section header */
        if (*s == '[') {
            char *end = strchr(s, ']');
            if (end) {
                *end = '\0';
                strncpy(section, s + 1, sizeof(section) - 1);
            }
            continue;
        }

        /* Key = Value */
        char *eq = strchr(s, '=');
        if (!eq) continue;
        *eq = '\0';
        char *key = strip(s);
        char *val = strip(eq + 1);

        if (strcmp(section, "general") == 0) {
            if (strcmp(key, "mod_key") == 0) {
                if (strcmp(val, "super") == 0)      cfg->mod_key = (1 << 6);
                else if (strcmp(val, "alt") == 0)    cfg->mod_key = (1 << 3);
            } else if (strcmp(key, "border_width") == 0) {
                cfg->border_width = atoi(val);
            } else if (strcmp(key, "focus_color") == 0) {
                cfg->focus_color = config_parse_color(val);
            } else if (strcmp(key, "unfocus_color") == 0) {
                cfg->unfocus_color = config_parse_color(val);
            } else if (strcmp(key, "num_workspaces") == 0) {
                cfg->num_workspaces = atoi(val);
                if (cfg->num_workspaces > MAX_WORKSPACES)
                    cfg->num_workspaces = MAX_WORKSPACES;
            } else if (strcmp(key, "terminal") == 0) {
                strncpy(cfg->term_cmd, val, MAX_VAL_LEN - 1);
            }
        } else if (strcmp(section, "bar") == 0) {
            if (strcmp(key, "enabled") == 0) {
                cfg->bar_enabled = (strcmp(val, "true") == 0 || strcmp(val, "1") == 0);
            } else if (strcmp(key, "position") == 0) {
                cfg->bar_position = parse_position(val);
            } else if (strcmp(key, "width") == 0) {
                cfg->bar_width = atoi(val);
            } else if (strcmp(key, "background") == 0) {
                cfg->bar_bg = config_parse_color(val);
            } else if (strcmp(key, "foreground") == 0) {
                cfg->bar_fg = config_parse_color(val);
            } else if (strcmp(key, "accent") == 0) {
                cfg->bar_accent = config_parse_color(val);
            } else if (strcmp(key, "font") == 0) {
                strncpy(cfg->bar_font, val, MAX_VAL_LEN - 1);
            } else if (strcmp(key, "follow_gtk") == 0) {
                cfg->bar_follow_gtk = (strcmp(val, "true") == 0 || strcmp(val, "1") == 0);
            }
        } else if (strcmp(section, "gaps") == 0) {
            if (strcmp(key, "inner") == 0) {
                cfg->gap_inner = atoi(val);
            } else if (strcmp(key, "outer") == 0) {
                cfg->gap_outer = atoi(val);
            } else if (strcmp(key, "smart_gaps") == 0) {
                cfg->smart_gaps = (strcmp(val, "true") == 0 || strcmp(val, "1") == 0);
            }
        } else if (strcmp(section, "compositor") == 0) {
            if (strcmp(key, "enabled") == 0) {
                cfg->compositor_enabled = (strcmp(val, "true") == 0 || strcmp(val, "1") == 0);
            } else if (strcmp(key, "corner_radius") == 0) {
                cfg->corner_radius = atoi(val);
            }
        } else if (strcmp(section, "wallpaper") == 0) {
            if (strcmp(key, "path") == 0) {
                strncpy(cfg->wallpaper_path, val, MAX_PATH_LEN - 1);
            } else if (strcmp(key, "color") == 0) {
                cfg->wallpaper_color = config_parse_color(val);
            } else if (strcmp(key, "mode") == 0) {
                strncpy(cfg->wallpaper_mode, val, MAX_KEY_LEN - 1);
            }
        }
    }

    fclose(f);
    LOG("Loaded config from %s", path);
}

/* ─── Auto-create default config ─────────────────────────── */

static int mkdirp(const char *path) {
    char tmp[MAX_PATH_LEN];
    snprintf(tmp, sizeof(tmp), "%s", path);
    for (char *p = tmp + 1; *p; p++) {
        if (*p == '/') {
            *p = '\0';
            mkdir(tmp, 0755);
            *p = '/';
        }
    }
    return mkdir(tmp, 0755);
}

void config_ensure_default(const char *path) {
    FILE *f = fopen(path, "r");
    if (f) { fclose(f); return; } /* already exists */

    /* Create parent directory */
    char dir[MAX_PATH_LEN];
    snprintf(dir, sizeof(dir), "%s", path);
    char *last_slash = strrchr(dir, '/');
    if (last_slash) {
        *last_slash = '\0';
        mkdirp(dir);
    }

    f = fopen(path, "w");
    if (!f) {
        WARN("Cannot create default config at %s", path);
        return;
    }

    fprintf(f,
        "; dumbWM configuration\n"
        "; Generated automatically on first run\n"
        "\n"
        "[general]\n"
        "mod_key = super\n"
        "border_width = 2\n"
        "focus_color = #0078D4\n"
        "unfocus_color = #333333\n"
        "num_workspaces = 9\n"
        "terminal = xterm\n"
        "\n"
        "[bar]\n"
        "enabled = true\n"
        "position = left\n"
        "width = 48\n"
        "background = #1e1e2e\n"
        "foreground = #cdd6f4\n"
        "accent = #0078D4\n"
        "follow_gtk = false\n"
        "\n"
        "[gaps]\n"
        "inner = 8\n"
        "outer = 8\n"
        "smart_gaps = true\n"
        "\n"
        "[compositor]\n"
        "enabled = true\n"
        "corner_radius = 12\n"
        "\n"
        "[wallpaper]\n"
        "; path = /path/to/wallpaper.jpg\n"
        "color = #1a1b26\n"
        "mode = fill\n"
        "\n"
        "; Keybinds (hardcoded):\n"
        ";   Super+Return       Open terminal\n"
        ";   Super+Q            Close focused window\n"
        ";   Super+D            Toggle application launcher\n"
        ";   Super+J            Focus next window\n"
        ";   Super+K            Focus previous window\n"
        ";   Super+Space        Toggle floating\n"
        ";   Super+1..9         Switch workspace\n"
        ";   Super+Shift+1..9   Move window to workspace\n"
        ";   Super+Shift+E      Quit dumbWM\n"
    );

    fclose(f);
    LOG("Created default config at %s", path);
}
