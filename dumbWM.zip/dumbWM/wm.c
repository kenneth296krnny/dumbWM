#include "wm.h"
#include "util.h"
#include "bar.h"
#include "bar.h"
#include "launcher.h"
#include "tray.h"
#include <X11/Xutil.h>
#include <X11/XKBlib.h>
#include <unistd.h>
#include <signal.h>
#include <sys/wait.h>
#include <sys/select.h>
#include <fcntl.h>

/* Forward declarations for event handlers */
static void handle_map_request(WM *wm, XEvent *e);
static void handle_unmap_notify(WM *wm, XEvent *e);
static void handle_destroy_notify(WM *wm, XEvent *e);
static void handle_configure_request(WM *wm, XEvent *e);
static void handle_key_press(WM *wm, XEvent *e);
static void handle_button_press(WM *wm, XEvent *e);
static void handle_enter_notify(WM *wm, XEvent *e);

static int xerror_handler(Display *dpy, XErrorEvent *ee);
static int xerror_start(Display *dpy, XErrorEvent *ee);
static int wm_detected = 0;

/* ─── Spawn ──────────────────────────────────────────────── */

void wm_spawn(const char *cmd) {
    if (!cmd || !cmd[0]) return;
    pid_t pid = fork();
    if (pid == 0) {
        /* Child process */
        setsid();
        /* Close all fds > 2 (including X display fd) */
        for (int fd = 3; fd < 1024; fd++)
            close(fd);
        /* Redirect stdio to /dev/null to prevent issues */
        int devnull = open("/dev/null", O_RDWR);
        if (devnull >= 0) {
            dup2(devnull, STDIN_FILENO);
            /* Keep stdout/stderr for debugging */
            close(devnull);
        }
        execl("/bin/sh", "sh", "-c", cmd, (char *)NULL);
        _exit(127);
    }
}

/* ─── Wallpaper ──────────────────────────────────────────── */

static void set_wallpaper(WM *wm) {
    Config *cfg = wm->cfg;

    /* Always set a solid root background color first */
    Colormap cmap = DefaultColormap(wm->dpy, wm->screen);
    XColor xc;
    xc.red   = ((cfg->wallpaper_color >> 16) & 0xFF) * 257;
    xc.green = ((cfg->wallpaper_color >>  8) & 0xFF) * 257;
    xc.blue  = ((cfg->wallpaper_color      ) & 0xFF) * 257;
    xc.flags = DoRed | DoGreen | DoBlue;
    XAllocColor(wm->dpy, cmap, &xc);
    XSetWindowBackground(wm->dpy, wm->root, xc.pixel);
    XClearWindow(wm->dpy, wm->root);
    XFlush(wm->dpy);

    /* If a wallpaper image path is set, use feh to set it */
    if (cfg->wallpaper_path[0] != '\0') {
        char cmd[1024];
        const char *mode_flag = "--bg-fill";
        if (strcmp(cfg->wallpaper_mode, "center") == 0)
            mode_flag = "--bg-center";
        else if (strcmp(cfg->wallpaper_mode, "tile") == 0)
            mode_flag = "--bg-tile";
        else if (strcmp(cfg->wallpaper_mode, "scale") == 0)
            mode_flag = "--bg-scale";
        else if (strcmp(cfg->wallpaper_mode, "max") == 0)
            mode_flag = "--bg-max";

        snprintf(cmd, sizeof(cmd), "feh %s '%s' 2>/dev/null", mode_flag, cfg->wallpaper_path);
        wm_spawn(cmd);
        LOG("Setting wallpaper: %s (%s)", cfg->wallpaper_path, cfg->wallpaper_mode);
    }
}

/* ─── Init ───────────────────────────────────────────────── */

void wm_init(WM *wm, Config *cfg) {
    wm->cfg = cfg;
    wm->running = 1;
    wm->current_ws = 0;
    wm->clients = NULL;
    wm->focused = NULL;
    wm->scratchpad = NULL;
    wm->meta_pressed = 0;

    for (int i = 0; i < MAX_WS; i++)
        wm->ws_trees[i] = NULL;

    wm->dpy = XOpenDisplay(NULL);
    if (!wm->dpy)
        die("Cannot open X display");

    wm->screen   = DefaultScreen(wm->dpy);
    wm->root     = RootWindow(wm->dpy, wm->screen);
    wm->screen_w = DisplayWidth(wm->dpy, wm->screen);
    wm->screen_h = DisplayHeight(wm->dpy, wm->screen);

    /* Check if another WM is running */
    wm_detected = 0;
    XSetErrorHandler(xerror_start);
    XSelectInput(wm->dpy, wm->root,
                 SubstructureRedirectMask | SubstructureNotifyMask |
                 StructureNotifyMask | ButtonPressMask);
    XSync(wm->dpy, False);
    if (wm_detected)
        die("Another window manager is already running");

    XSetErrorHandler(xerror_handler);

    /* Intern atoms */
    wm->wm_protocols    = XInternAtom(wm->dpy, "WM_PROTOCOLS", False);
    wm->wm_delete       = XInternAtom(wm->dpy, "WM_DELETE_WINDOW", False);
    wm->net_wm_name     = XInternAtom(wm->dpy, "_NET_WM_NAME", False);
    wm->net_active_window = XInternAtom(wm->dpy, "_NET_ACTIVE_WINDOW", False);

    /* Grab keys */
    XUngrabKey(wm->dpy, AnyKey, AnyModifier, wm->root);

    unsigned int mod = cfg->mod_key;

    /* Super+Return — terminal */
    XGrabKey(wm->dpy, XKeysymToKeycode(wm->dpy, XK_Return), mod,
             wm->root, True, GrabModeAsync, GrabModeAsync);
    /* Super+Q — kill */
    XGrabKey(wm->dpy, XKeysymToKeycode(wm->dpy, XK_q), mod,
             wm->root, True, GrabModeAsync, GrabModeAsync);
    /* Super+D — launcher */
    XGrabKey(wm->dpy, XKeysymToKeycode(wm->dpy, XK_d), mod,
             wm->root, True, GrabModeAsync, GrabModeAsync);
    /* Super+J / Super+K — focus */
    XGrabKey(wm->dpy, XKeysymToKeycode(wm->dpy, XK_j), mod,
             wm->root, True, GrabModeAsync, GrabModeAsync);
    XGrabKey(wm->dpy, XKeysymToKeycode(wm->dpy, XK_k), mod,
             wm->root, True, GrabModeAsync, GrabModeAsync);
    /* Super+Shift+E — quit */
    XGrabKey(wm->dpy, XKeysymToKeycode(wm->dpy, XK_e), mod | ShiftMask,
             wm->root, True, GrabModeAsync, GrabModeAsync);
    /* Super+Shift+R — reload config */
    XGrabKey(wm->dpy, XKeysymToKeycode(wm->dpy, XK_r), mod | ShiftMask,
             wm->root, True, GrabModeAsync, GrabModeAsync);
    /* Super+Space — toggle float */
    XGrabKey(wm->dpy, XKeysymToKeycode(wm->dpy, XK_space), mod,
             wm->root, True, GrabModeAsync, GrabModeAsync);
    /* Super+F — fullscreen toggle */
    XGrabKey(wm->dpy, XKeysymToKeycode(wm->dpy, XK_f), mod,
             wm->root, True, GrabModeAsync, GrabModeAsync);
    /* Super+S — open settings */
    XGrabKey(wm->dpy, XKeysymToKeycode(wm->dpy, XK_s), mod,
             wm->root, True, GrabModeAsync, GrabModeAsync);
    /* Super+Shift+S — open screenshot tool */
    XGrabKey(wm->dpy, XKeysymToKeycode(wm->dpy, XK_s), mod | ShiftMask,
             wm->root, True, GrabModeAsync, GrabModeAsync);

    /* Super+1..9 — workspace switch */
    for (int i = 0; i < cfg->num_workspaces && i < 9; i++) {
        XGrabKey(wm->dpy, XKeysymToKeycode(wm->dpy, XK_1 + i), mod,
                 wm->root, True, GrabModeAsync, GrabModeAsync);
        /* Super+Shift+1..9 — move to workspace */
        XGrabKey(wm->dpy, XKeysymToKeycode(wm->dpy, XK_1 + i), mod | ShiftMask,
                 wm->root, True, GrabModeAsync, GrabModeAsync);
    }

    /* Super+Minus — Toggle scratchpad */
    XGrabKey(wm->dpy, XKeysymToKeycode(wm->dpy, XK_minus), mod,
             wm->root, True, GrabModeAsync, GrabModeAsync);
    /* Super+Shift+Minus — Send to scratchpad */
    XGrabKey(wm->dpy, XKeysymToKeycode(wm->dpy, XK_minus), mod | ShiftMask,
             wm->root, True, GrabModeAsync, GrabModeAsync);

    /* Super_L alone — toggle launcher (grab both press and release) */
    XGrabKey(wm->dpy, XKeysymToKeycode(wm->dpy, XK_Super_L), AnyModifier,
             wm->root, True, GrabModeAsync, GrabModeAsync);

    /* Handle SIGCHLD to avoid zombies */
    signal(SIGCHLD, SIG_IGN);

    /* Manage pre-existing windows */
    Window root_ret, parent_ret;
    Window *children = NULL;
    unsigned int nchildren = 0;
    XQueryTree(wm->dpy, wm->root, &root_ret, &parent_ret, &children, &nchildren);
    for (unsigned int i = 0; i < nchildren; i++) {
        XWindowAttributes wa;
        if (XGetWindowAttributes(wm->dpy, children[i], &wa) &&
            wa.map_state == IsViewable && !wa.override_redirect) {
            wm_client_add(wm, children[i]);
        }
    }
    if (children) XFree(children);

    wm_tile(wm);

    /* Set wallpaper / root window background */
    set_wallpaper(wm);

    /* Launch compositor (picom) with rounded corners if configured */
    if (cfg->compositor_enabled) {
        char picom_cmd[256];
        snprintf(picom_cmd, sizeof(picom_cmd),
                 "picom --corner-radius %d --daemon 2>/dev/null || true",
                 cfg->corner_radius);
        wm_spawn(picom_cmd);
        LOG("Launched picom with corner-radius %d", cfg->corner_radius);
    }

    LOG("dumbWM initialized: %dx%d, %d workspaces", wm->screen_w, wm->screen_h, cfg->num_workspaces);
}

/* ─── Client Management ──────────────────────────────────── */

Client *wm_client_add(WM *wm, Window win) {
    /* Check if already managed */
    if (wm_client_find(wm, win))
        return wm_client_find(wm, win);

    Client *c = ecalloc(1, sizeof(Client));
    c->win = win;
    c->workspace = wm->current_ws;
    c->floating = 0;
    c->curr_x = wm->screen_w / 2.0f;
    c->curr_y = wm->screen_h / 2.0f;
    c->curr_w = 0.0f;
    c->curr_h = 0.0f;

    /* Add to client list */
    c->next = wm->clients;
    c->prev = NULL;
    if (wm->clients) wm->clients->prev = c;
    wm->clients = c;

    /* Insert into current workspace BSP tree */
    wm->ws_trees[wm->current_ws] = bsp_insert(wm->ws_trees[wm->current_ws], c, 0);

    /* Set border */
    XSetWindowBorderWidth(wm->dpy, win, wm->cfg->border_width);
    XSetWindowBorder(wm->dpy, win, wm->cfg->unfocus_color);

    /* Select events on this window */
    XSelectInput(wm->dpy, win, EnterWindowMask | StructureNotifyMask | PropertyChangeMask);

    wm_focus_client(wm, c);

    return c;
}

void wm_client_remove(WM *wm, Client *c) {
    if (!c) return;

    /* Remove from BSP tree */
    wm->ws_trees[c->workspace] = bsp_remove(wm->ws_trees[c->workspace], c);

    /* Remove from linked list */
    if (wm->scratchpad == c) wm->scratchpad = NULL;
    if (c->prev) c->prev->next = c->next;
    if (c->next) c->next->prev = c->prev;
    if (wm->clients == c) wm->clients = c->next;

    if (wm->focused == c) {
        /* Focus the next client on this workspace */
        wm->focused = NULL;
        for (Client *cl = wm->clients; cl; cl = cl->next) {
            if (cl->workspace == wm->current_ws) {
                wm_focus_client(wm, cl);
                break;
            }
        }
    }

    free(c);
}

Client *wm_client_find(WM *wm, Window win) {
    for (Client *c = wm->clients; c; c = c->next)
        if (c->win == win) return c;
    return NULL;
}

void wm_focus_client(WM *wm, Client *c) {
    if (wm->focused && wm->focused != c) {
        XSetWindowBorder(wm->dpy, wm->focused->win, wm->cfg->unfocus_color);
    }
    wm->focused = c;
    if (c) {
        XSetWindowBorder(wm->dpy, c->win, wm->cfg->focus_color);
        XSetInputFocus(wm->dpy, c->win, RevertToPointerRoot, CurrentTime);
        XRaiseWindow(wm->dpy, c->win);
    }
}

void wm_kill_client(WM *wm, Client *c) {
    if (!c) return;

    /* Try WM_DELETE_WINDOW protocol first */
    Atom *protocols = NULL;
    int n = 0;
    int supports_delete = 0;
    if (XGetWMProtocols(wm->dpy, c->win, &protocols, &n)) {
        for (int i = 0; i < n; i++) {
            if (protocols[i] == wm->wm_delete) {
                supports_delete = 1;
                break;
            }
        }
        if (protocols) XFree(protocols);
    }

    if (supports_delete) {
        XEvent ev;
        memset(&ev, 0, sizeof(ev));
        ev.type = ClientMessage;
        ev.xclient.window = c->win;
        ev.xclient.message_type = wm->wm_protocols;
        ev.xclient.format = 32;
        ev.xclient.data.l[0] = wm->wm_delete;
        ev.xclient.data.l[1] = CurrentTime;
        XSendEvent(wm->dpy, c->win, False, NoEventMask, &ev);
    } else {
        XKillClient(wm->dpy, c->win);
    }
}

/* ─── Layout / Tiling ────────────────────────────────────── */

void wm_tile(WM *wm) {
    int ws = wm->current_ws;
    BspNode *tree = wm->ws_trees[ws];
    if (!tree) return;

    /* Count tiled clients on this workspace */
    int tiled_count = 0;
    for (Client *c = wm->clients; c; c = c->next) {
        if (c->workspace == ws && !c->floating && c != wm->scratchpad)
            tiled_count++;
    }

    /* Smart gaps: disable gaps + borders when only 1 tiled window */
    int use_smart = (wm->cfg->smart_gaps && tiled_count == 1);

    int bar_offset = 0;
    int tile_x = 0, tile_y = 0, tile_w = wm->screen_w, tile_h = wm->screen_h;

    if (wm->cfg->bar_enabled) {
        bar_offset = wm->cfg->bar_width;
        switch (wm->cfg->bar_position) {
            case 0: /* left */
                tile_x = bar_offset;
                tile_w -= bar_offset;
                break;
            case 1: /* right */
                tile_w -= bar_offset;
                break;
            case 2: /* top */
                tile_y = bar_offset;
                tile_h -= bar_offset;
                break;
            case 3: /* bottom */
                tile_h -= bar_offset;
                break;
        }
    }

    /* Apply outer gaps (skip if smart gaps active) */
    int og = use_smart ? 0 : wm->cfg->gap_outer;
    tile_x += og;
    tile_y += og;
    tile_w -= 2 * og;
    tile_h -= 2 * og;

    int inner_gap = use_smart ? 0 : wm->cfg->gap_inner;

    bsp_update_geometry(tree, tile_x, tile_y, tile_w, tile_h);
    bsp_apply_layout(tree, inner_gap);

    /* Borders for all windows on this workspace */
    int bw = use_smart ? 0 : wm->cfg->border_width;
    for (Client *c = wm->clients; c; c = c->next) {
        if (c->workspace != ws) continue;
        if (!c->floating)
            XSetWindowBorderWidth(wm->dpy, c->win, bw);
    }

    XSync(wm->dpy, False);
}

void wm_workspace_switch(WM *wm, int ws) {
    if (ws < 0 || ws >= wm->cfg->num_workspaces || ws == wm->current_ws)
        return;

    /* Hide current workspace windows */
    for (Client *c = wm->clients; c; c = c->next) {
        if (c->workspace == wm->current_ws)
            XUnmapWindow(wm->dpy, c->win);
    }

    wm->current_ws = ws;

    /* Show new workspace windows */
    for (Client *c = wm->clients; c; c = c->next) {
        if (c->workspace == wm->current_ws)
            XMapWindow(wm->dpy, c->win);
    }

    wm->focused = NULL;
    for (Client *c = wm->clients; c; c = c->next) {
        if (c->workspace == wm->current_ws) {
            wm_focus_client(wm, c);
            break;
        }
    }

    wm_tile(wm);
    LOG("Switched to workspace %d", ws + 1);
}

static void client_move_to_workspace(WM *wm, Client *c, int ws) {
    if (!c || ws < 0 || ws >= wm->cfg->num_workspaces || ws == c->workspace)
        return;

    /* Remove from current workspace tree */
    wm->ws_trees[c->workspace] = bsp_remove(wm->ws_trees[c->workspace], c);

    XUnmapWindow(wm->dpy, c->win);
    c->workspace = ws;

    /* Insert into new workspace tree */
    wm->ws_trees[ws] = bsp_insert(wm->ws_trees[ws], c, 0);

    /* Re-tile current workspace */
    wm_tile(wm);
}

/* ─── Event Handlers ─────────────────────────────────────── */

static void handle_map_request(WM *wm, XEvent *e) {
    XMapRequestEvent *ev = &e->xmaprequest;
    XWindowAttributes wa;

    if (!XGetWindowAttributes(wm->dpy, ev->window, &wa))
        return;
    if (wa.override_redirect)
        return;

    Client *c = wm_client_find(wm, ev->window);
    if (!c) {
        c = wm_client_add(wm, ev->window);
    }

    XMapWindow(wm->dpy, ev->window);
    wm_tile(wm);
}

static void handle_unmap_notify(WM *wm, XEvent *e) {
    XUnmapEvent *ev = &e->xunmap;
    tray_handle_unmap_destroy(wm, ev->window);
    Client *c = wm_client_find(wm, ev->window);
    if (!c) return;
    /* Only remove if it's an unmap from this workspace */
    if (c->workspace == wm->current_ws || ev->send_event) {
        wm_client_remove(wm, c);
        wm_tile(wm);
    }
}

static void handle_destroy_notify(WM *wm, XEvent *e) {
    XDestroyWindowEvent *ev = &e->xdestroywindow;
    tray_handle_unmap_destroy(wm, ev->window);
    Client *c = wm_client_find(wm, ev->window);
    if (c) {
        wm_client_remove(wm, c);
        wm_tile(wm);
    }
}

static void handle_configure_request(WM *wm, XEvent *e) {
    XConfigureRequestEvent *ev = &e->xconfigurerequest;
    XWindowChanges wc;

    Client *c = wm_client_find(wm, ev->window);
    if (c && !c->floating) {
        /* Tiled: just acknowledge with current geometry */
        wc.x = c->x;
        wc.y = c->y;
        wc.width = c->w - 2 * wm->cfg->border_width;
        wc.height = c->h - 2 * wm->cfg->border_width;
        wc.border_width = wm->cfg->border_width;
        wc.sibling = ev->above;
        wc.stack_mode = ev->detail;
        XConfigureWindow(wm->dpy, ev->window, ev->value_mask, &wc);
    } else {
        /* Floating or unmanaged: honor the request */
        wc.x = ev->x;
        wc.y = ev->y;
        wc.width = ev->width;
        wc.height = ev->height;
        wc.border_width = ev->border_width;
        wc.sibling = ev->above;
        wc.stack_mode = ev->detail;
        XConfigureWindow(wm->dpy, ev->window, ev->value_mask, &wc);
    }
}

static Client *focus_next_client(WM *wm, int direction) {
    if (!wm->focused) return NULL;

    Client *start = wm->focused;
    Client *c = (direction > 0) ? start->next : start->prev;

    /* Wrap around */
    while (c && c->workspace != wm->current_ws)
        c = (direction > 0) ? c->next : c->prev;

    if (!c) {
        /* Wrap to beginning/end */
        c = (direction > 0) ? wm->clients : NULL;
        if (direction < 0) {
            for (Client *t = wm->clients; t; t = t->next)
                c = t; /* get last */
        }
        while (c && c->workspace != wm->current_ws && c != start)
            c = (direction > 0) ? c->next : c->prev;
    }

    if (c && c != start && c->workspace == wm->current_ws) {
        wm_focus_client(wm, c);
        return c;
    }
    return NULL;
}

static void handle_key_press(WM *wm, XEvent *e) {
    XKeyEvent *ev = &e->xkey;
    KeySym ks = XkbKeycodeToKeysym(wm->dpy, ev->keycode, 0, 0);
    unsigned int mod = wm->cfg->mod_key;
    unsigned int clean_mask = ev->state & ~(LockMask | Mod2Mask);

    if (ks == XK_Return && (clean_mask & mod)) {
        wm_spawn(wm->cfg->term_cmd);
    } else if (ks == XK_q && (clean_mask & mod)) {
        wm_kill_client(wm, wm->focused);
    } else if (ks == XK_d && (clean_mask & mod)) {
        launcher_toggle(wm);
    } else if (ks == XK_s && (clean_mask & mod)) {
        if (clean_mask & ShiftMask) {
            wm_spawn("dumbwm-screenshot");
        } else {
            wm_spawn("dumbwm-settings");
        }
    } else if (ks == XK_j && (clean_mask & mod)) {
        focus_next_client(wm, 1);
    } else if (ks == XK_k && (clean_mask & mod)) {
        focus_next_client(wm, -1);
    } else if (ks == XK_e && (clean_mask & (mod | ShiftMask)) == (mod | ShiftMask)) {
        wm->running = 0;
    } else if (ks == XK_r && (clean_mask & (mod | ShiftMask)) == (mod | ShiftMask)) {
        /* Mod+Shift+R — reload config */
        wm_reload_config(wm);
    } else if (ks == XK_space && (clean_mask & mod)) {
        /* Toggle float */
        if (wm->focused) {
            wm->focused->floating = !wm->focused->floating;
            if (wm->focused->floating) {
                /* Remove from BSP, center on screen */
                wm->ws_trees[wm->current_ws] =
                    bsp_remove(wm->ws_trees[wm->current_ws], wm->focused);
                wm->focused->w = wm->screen_w / 3;
                wm->focused->h = wm->screen_h / 3;
                wm->focused->x = (wm->screen_w - wm->focused->w) / 2;
                wm->focused->y = (wm->screen_h - wm->focused->h) / 2;
                XRaiseWindow(wm->dpy, wm->focused->win);
            } else {
                /* Re-insert into BSP */
                wm->ws_trees[wm->current_ws] =
                    bsp_insert(wm->ws_trees[wm->current_ws], wm->focused, 0);
            }
            wm_tile(wm);
        }
    } else if (ks == XK_minus && (clean_mask & mod)) {
        if (clean_mask & ShiftMask) {
            /* Send focused to scratchpad */
            if (wm->focused) {
                wm->scratchpad = wm->focused;
                client_move_to_workspace(wm, wm->focused, MAX_WS - 1);
            }
        } else {
            /* Toggle scratchpad */
            if (wm->scratchpad) {
                if (wm->scratchpad->workspace == wm->current_ws) {
                    client_move_to_workspace(wm, wm->scratchpad, MAX_WS - 1);
                } else {
                    client_move_to_workspace(wm, wm->scratchpad, wm->current_ws);
                    wm->scratchpad->floating = 1;
                    
                    /* Remove from BSP and re-center */
                    wm->ws_trees[wm->current_ws] = bsp_remove(wm->ws_trees[wm->current_ws], wm->scratchpad);
                    wm->scratchpad->w = wm->screen_w / 2;
                    wm->scratchpad->h = wm->screen_h / 2;
                    wm->scratchpad->x = (wm->screen_w - wm->scratchpad->w) / 2;
                    wm->scratchpad->y = (wm->screen_h - wm->scratchpad->h) / 2;
                    
                    wm_focus_client(wm, wm->scratchpad);
                    XRaiseWindow(wm->dpy, wm->scratchpad->win);
                    wm_tile(wm);
                }
            }
        }
    } else if (ks >= XK_1 && ks <= XK_9) {
        int ws = ks - XK_1;
        if (ws < wm->cfg->num_workspaces) {
            if (clean_mask & ShiftMask) {
                /* Move focused window to workspace */
                client_move_to_workspace(wm, wm->focused, ws);
            } else {
                wm_workspace_switch(wm, ws);
            }
        }
    }

    /* Any non-Super key pressed while Super held = cancel Meta-only toggle */
    if (ks != XK_Super_L && ks != XK_Super_R) {
        wm->meta_pressed = 0;
    }
}

static void handle_button_press(WM *wm, XEvent *e) {
    XButtonEvent *ev = &e->xbutton;
    bar_handle_click(wm, ev->x_root, ev->y_root);
}

static void handle_enter_notify(WM *wm, XEvent *e) {
    XCrossingEvent *ev = &e->xcrossing;
    Client *c = wm_client_find(wm, ev->window);
    if (c && c->workspace == wm->current_ws) {
        wm_focus_client(wm, c);
    }
}

/* ─── Error Handlers ─────────────────────────────────────── */

static int xerror_start(Display *dpy, XErrorEvent *ee) {
    (void)dpy; (void)ee;
    wm_detected = 1;
    return -1;
}

static int xerror_handler(Display *dpy, XErrorEvent *ee) {
    (void)dpy;
    /* Ignore common harmless errors */
    if (ee->error_code == BadWindow ||
        ee->error_code == BadDrawable ||
        ee->error_code == BadMatch ||
        ee->error_code == BadAccess)
        return 0;
    WARN("X error: request=%d error=%d", ee->request_code, ee->error_code);
    return 0;
}

/* ─── Main Loop ──────────────────────────────────────────── */

static void wm_animate(WM *wm) {
    int animating = 0;
    for (Client *c = wm->clients; c; c = c->next) {
        if (c->workspace != wm->current_ws) continue;

        float spring = 0.25f; /* 25% closer per frame */
        float dx = (float)c->x - c->curr_x;
        float dy = (float)c->y - c->curr_y;
        float dw = (float)c->w - c->curr_w;
        float dh = (float)c->h - c->curr_h;

        if (dx*dx > 1.0f || dy*dy > 1.0f || dw*dw > 1.0f || dh*dh > 1.0f) {
            c->curr_x += dx * spring;
            c->curr_y += dy * spring;
            c->curr_w += dw * spring;
            c->curr_h += dh * spring;
            animating = 1;
        } else {
            if (c->curr_x == c->x && c->curr_y == c->y && c->curr_w == c->w && c->curr_h == c->h)
                continue; /* Already at target */
            c->curr_x = c->x;
            c->curr_y = c->y;
            c->curr_w = c->w;
            c->curr_h = c->h;
        }

        XWindowAttributes wa;
        if (XGetWindowAttributes(wm->dpy, c->win, &wa)) {
            int bw = wa.border_width;
            int w = (int)c->curr_w - 2 * bw;
            int h = (int)c->curr_h - 2 * bw;
            if (w < 1) w = 1;
            if (h < 1) h = 1;

            XMoveResizeWindow(wm->dpy, c->win, (int)c->curr_x, (int)c->curr_y, w, h);
        }
    }
    if (animating) XSync(wm->dpy, False);
}

void wm_run(WM *wm) {
    XEvent ev;
    int x11_fd = ConnectionNumber(wm->dpy);

    while (wm->running) {
        /* Use select() for 60fps animation timeout (~16ms) */
        fd_set fds;
        struct timeval tv;
        FD_ZERO(&fds);
        FD_SET(x11_fd, &fds);
        tv.tv_sec = 0;
        tv.tv_usec = 16666; /* ~60fps */

        int ready = select(x11_fd + 1, &fds, NULL, NULL, &tv);

        if (ready > 0) {
            while (XPending(wm->dpy)) {
                XNextEvent(wm->dpy, &ev);

                /* Let launcher consume events first */
                if (launcher_handle_event(wm, &ev))
                    continue;

                switch (ev.type) {
                    case MapRequest:        handle_map_request(wm, &ev); break;
                    case UnmapNotify:       handle_unmap_notify(wm, &ev); break;
                    case DestroyNotify:     handle_destroy_notify(wm, &ev); break;
                    case ConfigureRequest:  handle_configure_request(wm, &ev); break;
                    case ClientMessage:     tray_handle_client_message(wm, &ev.xclient); break;
                    case PropertyNotify:    tray_handle_property_notify(wm, &ev.xproperty); break;
                    case KeyPress: {
                        KeySym ks = XkbKeycodeToKeysym(wm->dpy, ev.xkey.keycode, 0, 0);
                        if (ks == XK_Super_L) {
                            wm->meta_pressed = 1;
                        } else {
                            handle_key_press(wm, &ev);
                        }
                        break;
                    }
                    case KeyRelease: {
                        KeySym ks = XkbKeycodeToKeysym(wm->dpy, ev.xkey.keycode, 0, 0);
                        if (ks == XK_Super_L && wm->meta_pressed) {
                            wm->meta_pressed = 0;
                            launcher_toggle(wm);
                        }
                        break;
                    }
                    case ButtonPress:       handle_button_press(wm, &ev); break;
                    case EnterNotify:       handle_enter_notify(wm, &ev); break;
                }
            }
        }

        /* Check for SIGUSR1 config reload signal (from dumbwm-settings) */
        extern volatile int g_reload_requested;
        if (g_reload_requested) {
            g_reload_requested = 0;
            wm_reload_config(wm);
        }

        /* Update animations */
        wm_animate(wm);

        /* Periodic update: redraw bar (for clock updates, etc.) */
        bar_update(wm);
    }
}

/* ─── Config Reload ──────────────────────────────────────── */

void wm_reload_config(WM *wm) {
    if (wm->config_path[0] == '\0') {
        WARN("No config path set, cannot reload");
        return;
    }

    LOG("Reloading config from %s", wm->config_path);
    config_load(wm->cfg, wm->config_path);

    /* Re-apply borders to all clients */
    for (Client *c = wm->clients; c; c = c->next) {
        XSetWindowBorderWidth(wm->dpy, c->win, wm->cfg->border_width);
        if (c == wm->focused)
            XSetWindowBorder(wm->dpy, c->win, wm->cfg->focus_color);
        else
            XSetWindowBorder(wm->dpy, c->win, wm->cfg->unfocus_color);
    }

    /* Re-tile all workspaces */
    int saved_ws = wm->current_ws;
    for (int i = 0; i < wm->cfg->num_workspaces; i++) {
        wm->current_ws = i;
        wm_tile(wm);
    }
    wm->current_ws = saved_ws;

    /* Reload bar colors (picks up GTK theme if follow mode is on) */
    bar_reload_colors(wm);
    bar_update(wm);
    LOG("Config reloaded successfully");
}

void wm_cleanup(WM *wm) {
    /* Unmanage all clients */
    Client *c = wm->clients;
    while (c) {
        Client *next = c->next;
        XSetWindowBorderWidth(wm->dpy, c->win, 0);
        free(c);
        c = next;
    }

    /* Free BSP trees */
    for (int i = 0; i < MAX_WS; i++)
        bsp_free(wm->ws_trees[i]);

    XUngrabKey(wm->dpy, AnyKey, AnyModifier, wm->root);
    XCloseDisplay(wm->dpy);
    LOG("dumbWM cleaned up");
}
