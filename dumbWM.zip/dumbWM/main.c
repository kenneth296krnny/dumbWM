#include "wm.h"
#include "bar.h"
#include "nm.h"
#include "launcher.h"
#include "config.h"
#include "util.h"
#include <stdio.h>
#include <string.h>
#include <signal.h>
#include <unistd.h>

static WM   g_wm;
static Bar  g_main_bar;

static void sigterm_handler(int sig) {
    (void)sig;
    g_wm.running = 0;
}

volatile int g_reload_requested = 0;
static void sigusr1_handler(int sig) {
    (void)sig;
    g_reload_requested = 1;
}

static void print_usage(void) {
    fprintf(stderr, "Usage: dumbwm [-c config_path]\n");
}

int main(int argc, char **argv) {
    char config_path[512] = "";
    int opt;

    while ((opt = getopt(argc, argv, "c:h")) != -1) {
        switch (opt) {
            case 'c':
                strncpy(config_path, optarg, sizeof(config_path) - 1);
                break;
            case 'h':
                print_usage();
                return 0;
            default:
                print_usage();
                return 1;
        }
    }

    /* Default config path */
    if (config_path[0] == '\0') {
        const char *home = getenv("HOME");
        if (home)
            snprintf(config_path, sizeof(config_path), "%s/.config/dumbwm/config.ini", home);
        else
            strncpy(config_path, "/etc/dumbwm/config.ini", sizeof(config_path) - 1);
    }

    /* Ensure default config exists */
    config_ensure_default(config_path);

    /* Load config */
    Config cfg;
    config_load(&cfg, config_path);

    /* Set up signal handlers */
    signal(SIGTERM, sigterm_handler);
    signal(SIGINT,  sigterm_handler);
    signal(SIGUSR1, sigusr1_handler);

    /* Initialize NM monitoring */
    nm_init();

    /* Initialize WM */
    wm_init(&g_wm, &cfg);
    strncpy(g_wm.config_path, config_path, sizeof(g_wm.config_path) - 1);

    /* Initialize bar */
    if (cfg.bar_enabled) {
        bar_init(&g_main_bar, &g_wm);
    }

    /* Initialize launcher */
    launcher_init(&g_wm);

    LOG("dumbWM starting event loop");

    /* Run event loop */
    wm_run(&g_wm);

    /* Cleanup */
    launcher_destroy(&g_wm);
    bar_destroy(&g_main_bar, &g_wm);
    nm_cleanup();
    wm_cleanup(&g_wm);

    LOG("dumbWM exited cleanly");
    return 0;
}
