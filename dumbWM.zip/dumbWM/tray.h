#ifndef TRAY_H
#define TRAY_H

#include <X11/Xlib.h>

/* Forward declaration for WM */
typedef struct WM WM;

typedef struct TrayIcon {
    Window win;
    int w, h;
    struct TrayIcon *next;
} TrayIcon;

void tray_init(WM *wm, Window parent_win);
void tray_cleanup(WM *wm);
void tray_handle_client_message(WM *wm, XClientMessageEvent *ev);
void tray_handle_property_notify(WM *wm, XPropertyEvent *ev);
void tray_handle_unmap_destroy(WM *wm, Window win);
void tray_update(WM *wm, int x, int y, int h);
void tray_handle_configure_notify(WM *wm, XConfigureEvent *ev);

#endif /* TRAY_H */
