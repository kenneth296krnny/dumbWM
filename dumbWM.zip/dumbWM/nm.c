#include "nm.h"
#include "util.h"
#include <string.h>
#include <time.h>
#include <dbus/dbus.h>

static NmState g_nm_state;
static DBusConnection *g_dbus_conn = NULL;
static time_t g_last_poll = 0;

/* Forward declaration */
static void nm_query_active_connection(void);

#define NM_DBUS_SERVICE     "org.freedesktop.NetworkManager"
#define NM_DBUS_PATH        "/org/freedesktop/NetworkManager"
#define NM_DBUS_INTERFACE   "org.freedesktop.NetworkManager"
#define NM_POLL_INTERVAL    5  /* seconds */

int nm_init(void) {
    memset(&g_nm_state, 0, sizeof(g_nm_state));
    g_nm_state.state = NM_UNKNOWN;
    g_last_poll = 0;

    DBusError err;
    dbus_error_init(&err);

    g_dbus_conn = dbus_bus_get(DBUS_BUS_SYSTEM, &err);
    if (dbus_error_is_set(&err)) {
        WARN("D-Bus connection failed: %s", err.message);
        dbus_error_free(&err);
        g_dbus_conn = NULL;
        return 0;
    }

    /* Do initial poll */
    nm_poll();
    LOG("NetworkManager monitoring initialized");
    return 1;
}

/*
 * Query NM state via D-Bus.
 * NM state values:
 *   0 = Unknown, 10 = Asleep, 20 = Disconnected,
 *   30 = Disconnecting, 40 = Connecting,
 *   50 = Connected (local), 60 = Connected (site), 70 = Connected (global)
 */
void nm_poll(void) {
    if (!g_dbus_conn) {
        g_nm_state.state = NM_UNKNOWN;
        return;
    }

    time_t now = time(NULL);
    if (now - g_last_poll < NM_POLL_INTERVAL)
        return;
    g_last_poll = now;

    DBusMessage *msg = dbus_message_new_method_call(
        NM_DBUS_SERVICE, NM_DBUS_PATH,
        "org.freedesktop.DBus.Properties", "Get"
    );
    if (!msg) return;

    const char *iface = NM_DBUS_INTERFACE;
    const char *prop  = "State";
    dbus_message_append_args(msg,
        DBUS_TYPE_STRING, &iface,
        DBUS_TYPE_STRING, &prop,
        DBUS_TYPE_INVALID
    );

    DBusError err;
    dbus_error_init(&err);
    DBusMessage *reply = dbus_connection_send_with_reply_and_block(
        g_dbus_conn, msg, 1000, &err
    );
    dbus_message_unref(msg);

    if (dbus_error_is_set(&err)) {
        dbus_error_free(&err);
        g_nm_state.state = NM_UNKNOWN;
        return;
    }

    if (reply) {
        DBusMessageIter iter, variant;
        dbus_message_iter_init(reply, &iter);
        if (dbus_message_iter_get_arg_type(&iter) == DBUS_TYPE_VARIANT) {
            dbus_message_iter_recurse(&iter, &variant);
            if (dbus_message_iter_get_arg_type(&variant) == DBUS_TYPE_UINT32) {
                unsigned int nm_state;
                dbus_message_iter_get_basic(&variant, &nm_state);

                if (nm_state >= 50) {
                    /* Connected — try to determine wifi vs wired */
                    g_nm_state.state = NM_CONNECTED_WIRED; /* default to wired */
                    nm_query_active_connection();
                } else if (nm_state >= 20) {
                    g_nm_state.state = NM_DISCONNECTED;
                } else {
                    g_nm_state.state = NM_UNKNOWN;
                }
            }
        }
        dbus_message_unref(reply);
    }
}

/* Query the active connection to determine wifi/wired and get SSID */
static void nm_query_active_connection(void) {
    if (!g_dbus_conn) return;

    /* Get ActiveConnections property */
    DBusMessage *msg = dbus_message_new_method_call(
        NM_DBUS_SERVICE, NM_DBUS_PATH,
        "org.freedesktop.DBus.Properties", "Get"
    );
    if (!msg) return;

    const char *iface = NM_DBUS_INTERFACE;
    const char *prop  = "ActiveConnections";
    dbus_message_append_args(msg,
        DBUS_TYPE_STRING, &iface,
        DBUS_TYPE_STRING, &prop,
        DBUS_TYPE_INVALID
    );

    DBusError err;
    dbus_error_init(&err);
    DBusMessage *reply = dbus_connection_send_with_reply_and_block(
        g_dbus_conn, msg, 1000, &err
    );
    dbus_message_unref(msg);

    if (dbus_error_is_set(&err)) {
        dbus_error_free(&err);
        return;
    }

    if (!reply) return;

    DBusMessageIter iter, variant, array;
    dbus_message_iter_init(reply, &iter);
    if (dbus_message_iter_get_arg_type(&iter) != DBUS_TYPE_VARIANT) {
        dbus_message_unref(reply);
        return;
    }

    dbus_message_iter_recurse(&iter, &variant);
    if (dbus_message_iter_get_arg_type(&variant) != DBUS_TYPE_ARRAY) {
        dbus_message_unref(reply);
        return;
    }

    dbus_message_iter_recurse(&variant, &array);

    /* Check first active connection's type */
    while (dbus_message_iter_get_arg_type(&array) == DBUS_TYPE_OBJECT_PATH) {
        const char *conn_path;
        dbus_message_iter_get_basic(&array, &conn_path);

        /* Query the Type property of this active connection */
        DBusMessage *tmsg = dbus_message_new_method_call(
            NM_DBUS_SERVICE, conn_path,
            "org.freedesktop.DBus.Properties", "Get"
        );
        if (tmsg) {
            const char *ac_iface = "org.freedesktop.NetworkManager.Connection.Active";
            const char *type_prop = "Type";
            dbus_message_append_args(tmsg,
                DBUS_TYPE_STRING, &ac_iface,
                DBUS_TYPE_STRING, &type_prop,
                DBUS_TYPE_INVALID
            );

            DBusError terr;
            dbus_error_init(&terr);
            DBusMessage *treply = dbus_connection_send_with_reply_and_block(
                g_dbus_conn, tmsg, 1000, &terr
            );
            dbus_message_unref(tmsg);

            if (!dbus_error_is_set(&terr) && treply) {
                DBusMessageIter titer, tvariant;
                dbus_message_iter_init(treply, &titer);
                if (dbus_message_iter_get_arg_type(&titer) == DBUS_TYPE_VARIANT) {
                    dbus_message_iter_recurse(&titer, &tvariant);
                    if (dbus_message_iter_get_arg_type(&tvariant) == DBUS_TYPE_STRING) {
                        const char *type;
                        dbus_message_iter_get_basic(&tvariant, &type);
                        if (strstr(type, "wireless") || strstr(type, "wifi") ||
                            strstr(type, "802-11")) {
                            g_nm_state.state = NM_CONNECTED_WIFI;
                            strncpy(g_nm_state.ssid, "(Wi-Fi)", sizeof(g_nm_state.ssid) - 1);
                        }
                    }
                }
                dbus_message_unref(treply);
            }
            if (dbus_error_is_set(&terr))
                dbus_error_free(&terr);
        }

        if (!dbus_message_iter_has_next(&array)) break;
        dbus_message_iter_next(&array);
    }

    dbus_message_unref(reply);
}

void nm_get_state(NmState *out) {
    nm_poll(); /* Only polls if interval has elapsed */
    *out = g_nm_state;
}

void nm_cleanup(void) {
    if (g_dbus_conn) {
        dbus_connection_unref(g_dbus_conn);
        g_dbus_conn = NULL;
    }
}
