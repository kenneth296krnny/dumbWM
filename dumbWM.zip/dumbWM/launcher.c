#include "launcher.h"
#include "wm.h"
#include "util.h"
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/keysym.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <unistd.h>
#include <ctype.h>
#include <sys/stat.h>
#include <cairo/cairo.h>
#include <cairo/cairo-xlib.h>
#include <librsvg/rsvg.h>

#define MAX_APPS        2048
#define MAX_NAME_LEN    256
#define MAX_EXEC_LEN    512

#define GRID_COLS       7
#define GRID_ICON_SZ    64
#define GRID_CELL_W     110
#define GRID_CELL_H     120
#define GRID_PAD_TOP    100
#define GRID_PAD_BOTTOM 100
#define SEARCH_W        400
#define SEARCH_H        40

static double col_bg[3]        = {0.102, 0.102, 0.180};  /* #1a1a2e */
static double col_search_bg[3] = {0.165, 0.165, 0.243};  /* #2a2a3e */
static double col_accent[3]    = {0.000, 0.471, 0.831};  /* #0078D4 */
static double col_text[3]      = {1.000, 1.000, 1.000};
static double col_text_dim[3]  = {0.533, 0.533, 0.533};
static double col_logout[3]    = {0.000, 0.471, 0.831};
static double col_restart[3]   = {0.855, 0.318, 0.000};
static double col_shutdown[3]  = {0.910, 0.067, 0.137};

static const unsigned long LP_ICON_COLORS[] = {
    0x0078D4, 0x107C10, 0xDA5100, 0x5C2D91,
    0xE81123, 0x009688, 0xF7630C, 0x881798,
};
#define LP_ICON_COLORS_N 8

typedef struct {
    char name[MAX_NAME_LEN];
    char exec[MAX_EXEC_LEN];
    char icon_name[MAX_NAME_LEN];
    int  from_desktop;
    cairo_surface_t *icon_surf;
} AppEntry;

typedef struct {
    Window       win;
    GC           gc;
    Pixmap       buffer;
    int          visible;
    int          x, y, w, h;
    AppEntry     apps[MAX_APPS];
    int          app_count;
    int          filtered[MAX_APPS];
    int          filter_count;
    char         search[256];
    int          search_len;
    int          selected;
    int          scroll_offset;
    WM          *wm;
    int          grid_rows;
    int          grid_x0, grid_y0;
} Launcher;

static Launcher g_launcher;
static int g_launcher_initialized = 0;
static char g_icon_theme[256] = "Qogir";

static void hex_to_rgb(unsigned long hex, double *r, double *g, double *b) {
    *r = ((hex >> 16) & 0xFF) / 255.0;
    *g = ((hex >>  8) & 0xFF) / 255.0;
    *b = ((hex      ) & 0xFF) / 255.0;
}

static cairo_surface_t *load_svg_icon(const char *icon_name, int size) {
    char paths[8][512];
    int np = 0;
    const char *home = getenv("HOME");
    
    // First try as absolute path
    if (icon_name[0] == '/') {
        snprintf(paths[np++], 512, "%s", icon_name);
    } else {
        snprintf(paths[np++], 512, "/usr/share/icons/%s/%d/apps/%s.svg", g_icon_theme, size, icon_name);
        snprintf(paths[np++], 512, "/usr/share/icons/%s/scalable/apps/%s.svg", g_icon_theme, icon_name);
        snprintf(paths[np++], 512, "/usr/share/icons/%s/%d/apps/%s.png", g_icon_theme, size, icon_name);
        snprintf(paths[np++], 512, "/usr/share/icons/hicolor/scalable/apps/%s.svg", icon_name);
        snprintf(paths[np++], 512, "/usr/share/icons/hicolor/48x48/apps/%s.png", icon_name);
        snprintf(paths[np++], 512, "/usr/share/pixmaps/%s.png", icon_name);
        snprintf(paths[np++], 512, "/usr/share/pixmaps/%s.svg", icon_name);
    }

    for (int i = 0; i < np; i++) {
        FILE *f = fopen(paths[i], "r");
        if (!f) continue;
        fclose(f);

        char *ext = strrchr(paths[i], '.');
        if (ext && strcmp(ext, ".svg") == 0) {
            GError *err = NULL;
            RsvgHandle *svg = rsvg_handle_new_from_file(paths[i], &err);
            if (svg) {
                cairo_surface_t *surf = cairo_image_surface_create(CAIRO_FORMAT_ARGB32, size, size);
                cairo_t *cr = cairo_create(surf);
                RsvgRectangle viewport = { 0, 0, size, size };
                rsvg_handle_render_document(svg, cr, &viewport, NULL);
                cairo_destroy(cr);
                g_object_unref(svg);
                return surf;
            } else if (err) {
                g_error_free(err);
            }
        } else if (ext && strcmp(ext, ".png") == 0) {
            cairo_surface_t *surf = cairo_image_surface_create_from_png(paths[i]);
            if (cairo_surface_status(surf) == CAIRO_STATUS_SUCCESS) {
                /* Scale to size */
                int w = cairo_image_surface_get_width(surf);
                int h = cairo_image_surface_get_height(surf);
                cairo_surface_t *scaled = cairo_image_surface_create(CAIRO_FORMAT_ARGB32, size, size);
                cairo_t *cr = cairo_create(scaled);
                cairo_scale(cr, (double)size / w, (double)size / h);
                cairo_set_source_surface(cr, surf, 0, 0);
                cairo_paint(cr);
                cairo_destroy(cr);
                cairo_surface_destroy(surf);
                return scaled;
            }
            cairo_surface_destroy(surf);
        }
    }
    return NULL;
}

static int is_executable(const char *path) {
    struct stat st;
    return (stat(path, &st) == 0 && S_ISREG(st.st_mode) && (st.st_mode & S_IXUSR));
}

static int app_exists(Launcher *l, const char *name) {
    for (int i = 0; i < l->app_count; i++) {
        if (strcmp(l->apps[i].name, name) == 0) return 1;
    }
    return 0;
}

static void scan_path_binaries(Launcher *l) {
    const char *path_env = getenv("PATH");
    if (!path_env) return;
    char *path_copy = strdup(path_env);
    if (!path_copy) return;
    char *saveptr = NULL;
    char *dir = strtok_r(path_copy, ":", &saveptr);
    while (dir && l->app_count < MAX_APPS) {
        DIR *d = opendir(dir);
        if (!d) { dir = strtok_r(NULL, ":", &saveptr); continue; }
        struct dirent *de;
        while ((de = readdir(d)) && l->app_count < MAX_APPS) {
            if (de->d_name[0] == '.' || strlen(de->d_name) <= 1) continue;
            if (app_exists(l, de->d_name)) continue;
            char fp[1024]; snprintf(fp, sizeof(fp), "%s/%s", dir, de->d_name);
            if (is_executable(fp)) {
                AppEntry *e = &l->apps[l->app_count];
                snprintf(e->name, MAX_NAME_LEN, "%s", de->d_name);
                snprintf(e->exec, MAX_EXEC_LEN, "%s", de->d_name);
                e->icon_name[0] = '\0';
                e->from_desktop = 0;
                e->icon_surf = NULL;
                l->app_count++;
            }
        }
        closedir(d);
        dir = strtok_r(NULL, ":", &saveptr);
    }
    free(path_copy);
}

static int parse_desktop_file(const char *path, AppEntry *entry) {
    FILE *f = fopen(path, "r");
    if (!f) return 0;
    char line[1024];
    int in_desktop_entry = 0, has_name = 0, has_exec = 0, no_display = 0;
    entry->name[0] = '\0'; entry->exec[0] = '\0'; entry->icon_name[0] = '\0';
    while (fgets(line, sizeof(line), f)) {
        char *nl = strchr(line, '\n'); if (nl) *nl = '\0';
        if (line[0] == '[') {
            in_desktop_entry = (strcmp(line, "[Desktop Entry]") == 0);
            continue;
        }
        if (!in_desktop_entry) continue;
        if (strncmp(line, "Name=", 5) == 0 && !has_name) {
            snprintf(entry->name, MAX_NAME_LEN, "%s", line + 5); has_name = 1;
        } else if (strncmp(line, "Exec=", 5) == 0 && !has_exec) {
            char *src = line + 5, *dst = entry->exec; int dlen = 0;
            while (*src && dlen < MAX_EXEC_LEN - 1) {
                if (*src == '%' && *(src + 1)) { src += 2; }
                else { *dst++ = *src++; dlen++; }
            }
            *dst = '\0';
            while (dlen > 0 && isspace((unsigned char)entry->exec[dlen - 1]))
                entry->exec[--dlen] = '\0';
            has_exec = 1;
        } else if (strncmp(line, "Icon=", 5) == 0) {
            snprintf(entry->icon_name, MAX_NAME_LEN, "%s", line + 5);
        } else if (strncmp(line, "NoDisplay=true", 14) == 0) {
            no_display = 1;
        } else if (strncmp(line, "Type=", 5) == 0) {
            if (strcmp(line + 5, "Application") != 0) { fclose(f); return 0; }
        }
    }
    fclose(f);
    return has_name && has_exec && !no_display;
}

static void load_desktop_files(Launcher *l) {
    const char *dirs[] = { "/usr/share/applications", "/usr/local/share/applications", NULL };
    char user_dir[512] = "";
    const char *home = getenv("HOME");
    if (home) snprintf(user_dir, sizeof(user_dir), "%s/.local/share/applications", home);

    for (int d = 0; dirs[d] && l->app_count < MAX_APPS; d++) {
        DIR *dir = opendir(dirs[d]);
        if (!dir) continue;
        struct dirent *de;
        while ((de = readdir(dir)) && l->app_count < MAX_APPS) {
            char *ext = strrchr(de->d_name, '.');
            if (!ext || strcmp(ext, ".desktop") != 0) continue;
            char path[1024]; snprintf(path, sizeof(path), "%s/%s", dirs[d], de->d_name);
            AppEntry entry; entry.from_desktop = 1; entry.icon_surf = NULL;
            if (parse_desktop_file(path, &entry) && !app_exists(l, entry.name)) {
                if (entry.icon_name[0]) {
                    entry.icon_surf = load_svg_icon(entry.icon_name, GRID_ICON_SZ);
                }
                l->apps[l->app_count++] = entry;
            }
        }
        closedir(dir);
    }
}

static int app_compare(const void *a, const void *b) {
    const AppEntry *ea = a, *eb = b;
    if (ea->from_desktop != eb->from_desktop) return eb->from_desktop - ea->from_desktop;
    return strcasecmp(ea->name, eb->name);
}

static void load_applications(Launcher *l) {
    l->app_count = 0;
    
    // Read gtk icon theme name just in case
    const char *home = getenv("HOME");
    if (home) {
        char path[512]; snprintf(path, sizeof(path), "%s/.config/gtk-3.0/settings.ini", home);
        FILE *f = fopen(path, "r");
        if (f) {
            char line[1024];
            while (fgets(line, sizeof(line), f)) {
                char *s = line; while (*s == ' ' || *s == '\t') s++;
                if (strncmp(s, "gtk-icon-theme-name", 19) == 0) {
                    char *eq = strchr(s, '=');
                    if (eq) {
                        eq++; while (*eq == ' ' || *eq == '\t') eq++;
                        char *end = eq + strlen(eq) - 1;
                        while (end > eq && (*end == '\n' || *end == '\r' || *end == ' ')) *end-- = '\0';
                        strncpy(g_icon_theme, eq, sizeof(g_icon_theme) - 1);
                    }
                }
            }
            fclose(f);
        }
    }
    
    load_desktop_files(l);
    scan_path_binaries(l);
    qsort(l->apps, l->app_count, sizeof(AppEntry), app_compare);
    LOG("Loaded %d applications (icon theme: %s)", l->app_count, g_icon_theme);
}

static void update_filter(Launcher *l) {
    l->filter_count = 0;
    for (int i = 0; i < l->app_count && l->filter_count < MAX_APPS; i++) {
        if (l->search_len == 0) {
            if (l->apps[i].from_desktop) l->filtered[l->filter_count++] = i;
        } else {
            if (strcasestr(l->apps[i].name, l->search) || strcasestr(l->apps[i].exec, l->search))
                l->filtered[l->filter_count++] = i;
        }
    }
    l->selected = 0; l->scroll_offset = 0;
}

static void cr_rounded_rect(cairo_t *cr, double x, double y, double w, double h, double r) {
    cairo_new_sub_path(cr);
    cairo_arc(cr, x + w - r, y + r,     r, -G_PI/2, 0);
    cairo_arc(cr, x + w - r, y + h - r, r,  0,       G_PI/2);
    cairo_arc(cr, x + r,     y + h - r, r,  G_PI/2,  G_PI);
    cairo_arc(cr, x + r,     y + r,     r,  G_PI,    3*G_PI/2);
    cairo_close_path(cr);
}

static void cr_text_centered(cairo_t *cr, double x, double y, double w, double h, const char *text, double font_size) {
    cairo_set_font_size(cr, font_size);
    cairo_text_extents_t ext; cairo_text_extents(cr, text, &ext);
    cairo_move_to(cr, x + (w - ext.width) / 2 - ext.x_bearing, y + (h - ext.height) / 2 - ext.y_bearing);
    cairo_show_text(cr, text);
}

static void launcher_draw(Launcher *l, WM *wm) {
    cairo_surface_t *surf = cairo_xlib_surface_create(wm->dpy, l->buffer, DefaultVisual(wm->dpy, wm->screen), l->w, l->h);
    cairo_t *cr = cairo_create(surf);
    cairo_select_font_face(cr, "Sans", CAIRO_FONT_SLANT_NORMAL, CAIRO_FONT_WEIGHT_NORMAL);

    cairo_set_source_rgb(cr, col_bg[0], col_bg[1], col_bg[2]);
    cairo_paint(cr);

    int search_x = (l->w - SEARCH_W) / 2, search_y = 30;
    cairo_set_source_rgb(cr, col_search_bg[0], col_search_bg[1], col_search_bg[2]);
    cr_rounded_rect(cr, search_x, search_y, SEARCH_W, SEARCH_H, 8); cairo_fill(cr);

    cairo_set_source_rgb(cr, col_accent[0], col_accent[1], col_accent[2]);
    cr_rounded_rect(cr, search_x, search_y, 4, SEARCH_H, 2); cairo_fill(cr);

    if (l->search_len > 0) {
        char buf[280]; snprintf(buf, sizeof(buf), "%s|", l->search);
        cairo_set_source_rgb(cr, col_text[0], col_text[1], col_text[2]);
        cairo_set_font_size(cr, 16); cairo_move_to(cr, search_x + 14, search_y + 26); cairo_show_text(cr, buf);
    } else {
        cairo_set_source_rgb(cr, col_text_dim[0], col_text_dim[1], col_text_dim[2]);
        cairo_set_font_size(cr, 16); cairo_move_to(cr, search_x + 14, search_y + 26); cairo_show_text(cr, "Type to search...");
    }

    int grid_w = GRID_COLS * GRID_CELL_W, grid_x = (l->w - grid_w) / 2, grid_y = GRID_PAD_TOP;
    int avail_h = l->h - GRID_PAD_TOP - GRID_PAD_BOTTOM;
    int vis_rows = avail_h / GRID_CELL_H; if (vis_rows < 1) vis_rows = 1;
    l->grid_rows = vis_rows; l->grid_x0 = grid_x; l->grid_y0 = grid_y;
    int items_per_page = vis_rows * GRID_COLS, start_idx = l->scroll_offset * GRID_COLS;

    for (int i = 0; i < items_per_page && (start_idx + i) < l->filter_count; i++) {
        int idx = l->filtered[start_idx + i], col = i % GRID_COLS, row = i / GRID_COLS;
        int cx = grid_x + col * GRID_CELL_W, cy = grid_y + row * GRID_CELL_H, is_sel = ((start_idx + i) == l->selected);
        int ix = cx + (GRID_CELL_W - GRID_ICON_SZ)/2, iy = cy + 4;

        if (is_sel) {
            cairo_set_source_rgba(cr, col_text[0], col_text[1], col_text[2], 0.15);
            cr_rounded_rect(cr, cx + 10, cy, GRID_CELL_W - 20, GRID_CELL_H - 10, 12); cairo_fill(cr);
        }

        if (l->apps[idx].icon_surf) {
            cairo_save(cr);
            cairo_set_source_surface(cr, l->apps[idx].icon_surf, ix, iy);
            cairo_paint(cr);
            cairo_restore(cr);
        } else {
            double r, g, b; hex_to_rgb(LP_ICON_COLORS[idx % LP_ICON_COLORS_N], &r, &g, &b);
            cairo_set_source_rgb(cr, r, g, b);
            cr_rounded_rect(cr, ix, iy, GRID_ICON_SZ, GRID_ICON_SZ, 16); cairo_fill(cr);
            char letter[2] = { toupper((unsigned char)l->apps[idx].name[0]), '\0' };
            cairo_set_source_rgb(cr, col_text[0], col_text[1], col_text[2]);
            cr_text_centered(cr, ix, iy, GRID_ICON_SZ, GRID_ICON_SZ, letter, 28);
        }

        char trunc[18]; snprintf(trunc, sizeof(trunc), "%.16s", l->apps[idx].name);
        cairo_set_source_rgb(cr, is_sel ? col_text[0] : col_text_dim[0], is_sel ? col_text[1] : col_text_dim[1], is_sel ? col_text[2] : col_text_dim[2]);
        cr_text_centered(cr, cx, iy + GRID_ICON_SZ + 8, GRID_CELL_W, 20, trunc, 13);
    }

    int total_pages = (l->filter_count + items_per_page - 1) / items_per_page; if (total_pages < 1) total_pages = 1;
    int cur_page = l->scroll_offset / vis_rows;
    if (total_pages > 1) {
        int dot_sz = 8, dot_gap = 12, dots_w = total_pages * (dot_sz + dot_gap) - dot_gap;
        int dots_x = (l->w - dots_w) / 2, dots_y = l->h - GRID_PAD_BOTTOM + 4;
        for (int p = 0; p < total_pages; p++) {
            cairo_set_source_rgb(cr, p == cur_page ? col_accent[0] : col_text_dim[0], p == cur_page ? col_accent[1] : col_text_dim[1], p == cur_page ? col_accent[2] : col_text_dim[2]);
            cairo_arc(cr, dots_x + p * (dot_sz + dot_gap) + dot_sz/2.0, dots_y + dot_sz/2.0, dot_sz/2.0, 0, 2*G_PI); cairo_fill(cr);
        }
    }

    int sess_y = l->h - 50, btn_w = 110, btn_h = 34, btn_gap = 12, btn_x0 = (l->w - (3*btn_w + 2*btn_gap)) / 2;
    struct { const char *l; double *c; } btns[3] = { {"Log Out", col_logout}, {"Restart", col_restart}, {"Shutdown", col_shutdown} };
    for (int i = 0; i < 3; i++) {
        cairo_set_source_rgb(cr, btns[i].c[0], btns[i].c[1], btns[i].c[2]);
        cr_rounded_rect(cr, btn_x0 + i*(btn_w+btn_gap), sess_y, btn_w, btn_h, 8); cairo_fill(cr);
        cairo_set_source_rgb(cr, col_text[0], col_text[1], col_text[2]);
        cr_text_centered(cr, btn_x0 + i*(btn_w+btn_gap), sess_y, btn_w, btn_h, btns[i].l, 14);
    }

    cairo_destroy(cr); cairo_surface_destroy(surf);
    XCopyArea(wm->dpy, l->buffer, l->win, l->gc, 0, 0, l->w, l->h, 0, 0);
    XFlush(wm->dpy);
}

void launcher_init(WM *wm) {
    Launcher *l = &g_launcher; memset(l, 0, sizeof(Launcher)); l->wm = wm;
    load_applications(l); update_filter(l);
    int bar_w = wm->cfg->bar_enabled ? wm->cfg->bar_width : 0;
    l->x = (wm->cfg->bar_position == 0) ? bar_w : 0; l->y = (wm->cfg->bar_position == 2) ? bar_w : 0;
    l->w = (wm->cfg->bar_position == 0 || wm->cfg->bar_position == 1) ? wm->screen_w - bar_w : wm->screen_w;
    l->h = (wm->cfg->bar_position == 2 || wm->cfg->bar_position == 3) ? wm->screen_h - bar_w : wm->screen_h;
    XSetWindowAttributes wa; wa.override_redirect = True; wa.background_pixel = BlackPixel(wm->dpy, wm->screen);
    wa.event_mask = ExposureMask | KeyPressMask | ButtonPressMask | PointerMotionMask | FocusChangeMask;
    l->win = XCreateWindow(wm->dpy, wm->root, l->x, l->y, l->w, l->h, 0, DefaultDepth(wm->dpy, wm->screen), InputOutput,
                           DefaultVisual(wm->dpy, wm->screen), CWOverrideRedirect | CWBackPixel | CWEventMask, &wa);
    l->gc = XCreateGC(wm->dpy, l->win, 0, NULL);
    l->buffer = XCreatePixmap(wm->dpy, l->win, l->w, l->h, DefaultDepth(wm->dpy, wm->screen));
    l->visible = 0; g_launcher_initialized = 1;
}

void launcher_toggle(WM *wm) {
    if (!g_launcher_initialized) launcher_init(wm);
    Launcher *l = &g_launcher;
    if (l->visible) {
        XUnmapWindow(wm->dpy, l->win); l->visible = 0; XUngrabKeyboard(wm->dpy, CurrentTime);
    } else {
        l->search[0] = '\0'; l->search_len = 0; l->selected = 0; l->scroll_offset = 0; update_filter(l);
        XMapRaised(wm->dpy, l->win);
        int grab = XGrabKeyboard(wm->dpy, l->win, True, GrabModeAsync, GrabModeAsync, CurrentTime);
        if (grab != GrabSuccess) { usleep(50000); XGrabKeyboard(wm->dpy, l->win, True, GrabModeAsync, GrabModeAsync, CurrentTime); }
        XSetInputFocus(wm->dpy, l->win, RevertToPointerRoot, CurrentTime);
        l->visible = 1; launcher_draw(l, wm);
    }
}

static void launcher_launch_selected(Launcher *l, WM *wm) {
    if (l->selected >= 0 && l->selected < l->filter_count) {
        XUnmapWindow(wm->dpy, l->win); l->visible = 0; XUngrabKeyboard(wm->dpy, CurrentTime); XSync(wm->dpy, False);
        wm_spawn(l->apps[l->filtered[l->selected]].exec);
    }
}

static void launcher_run_command(Launcher *l, WM *wm) {
    if (l->search_len > 0) {
        XUnmapWindow(wm->dpy, l->win); l->visible = 0; XUngrabKeyboard(wm->dpy, CurrentTime); XSync(wm->dpy, False);
        wm_spawn(l->search);
    }
}

int launcher_handle_event(WM *wm, void *event) {
    if (!g_launcher_initialized || !g_launcher.visible) return 0;
    Launcher *l = &g_launcher; XEvent *ev = (XEvent *)event;
    if (ev->type == KeyPress) {
        KeySym ks = XLookupKeysym(&ev->xkey, 0); unsigned int state = ev->xkey.state;
        if (ks == XK_Escape) { launcher_toggle(wm); return 1; }
        else if (ks == XK_Return) { if (state & ShiftMask) launcher_run_command(l, wm); else if (l->filter_count > 0) launcher_launch_selected(l, wm); else launcher_run_command(l, wm); return 1; }
        else if (ks == XK_Up) { if (l->selected >= GRID_COLS) l->selected -= GRID_COLS; if (l->selected < l->scroll_offset*GRID_COLS && l->scroll_offset > 0) l->scroll_offset -= l->grid_rows; launcher_draw(l, wm); return 1; }
        else if (ks == XK_Down) { if (l->selected + GRID_COLS < l->filter_count) l->selected += GRID_COLS; if (l->selected >= (l->scroll_offset+l->grid_rows)*GRID_COLS) l->scroll_offset += l->grid_rows; launcher_draw(l, wm); return 1; }
        else if (ks == XK_Left) { if (l->selected > 0) l->selected--; if (l->selected < l->scroll_offset*GRID_COLS && l->scroll_offset > 0) l->scroll_offset -= l->grid_rows; launcher_draw(l, wm); return 1; }
        else if (ks == XK_Right) { if (l->selected < l->filter_count - 1) l->selected++; if (l->selected >= (l->scroll_offset+l->grid_rows)*GRID_COLS) l->scroll_offset += l->grid_rows; launcher_draw(l, wm); return 1; }
        else if (ks == XK_BackSpace) { if (l->search_len > 0) { l->search[--l->search_len] = '\0'; update_filter(l); launcher_draw(l, wm); } return 1; }
        else if (ks == XK_Tab) { if (l->filter_count > 0) { strncpy(l->search, l->apps[l->filtered[l->selected]].exec, sizeof(l->search)-1); l->search_len = strlen(l->search); update_filter(l); launcher_draw(l, wm); } return 1; }
        else { char buf[8]; int len = XLookupString(&ev->xkey, buf, sizeof(buf), NULL, NULL); if (len > 0 && l->search_len < (int)sizeof(l->search)-2) { for (int i = 0; i < len; i++) if (isprint((unsigned char)buf[i])) l->search[l->search_len++] = buf[i]; l->search[l->search_len] = '\0'; update_filter(l); launcher_draw(l, wm); } return 1; }
    } else if (ev->type == ButtonPress && ev->xbutton.window == l->win) {
        int rel_x = ev->xbutton.x, rel_y = ev->xbutton.y;
        int sess_y = l->h - 50, btn_w = 110, btn_h = 34, btn_gap = 12, btn_x0 = (l->w - (3*btn_w + 2*btn_gap)) / 2;
        if (rel_y >= sess_y && rel_y < sess_y + btn_h) {
            int btn_idx = -1; for (int i = 0; i < 3; i++) { int bx = btn_x0 + i*(btn_w+btn_gap); if (rel_x >= bx && rel_x < bx + btn_w) btn_idx = i; }
            XUnmapWindow(wm->dpy, l->win); l->visible = 0; XUngrabKeyboard(wm->dpy, CurrentTime); XSync(wm->dpy, False);
            switch (btn_idx) { case 0: wm->running = 0; break; case 1: wm_spawn("systemctl reboot"); break; case 2: wm_spawn("systemctl poweroff"); break; }
            return 1;
        }
        if (rel_x >= l->grid_x0 && rel_y >= l->grid_y0) {
            int col = (rel_x - l->grid_x0) / GRID_CELL_W, row = (rel_y - l->grid_y0) / GRID_CELL_H;
            if (col >= 0 && col < GRID_COLS && row >= 0 && row < l->grid_rows) {
                int abs_idx = l->scroll_offset * GRID_COLS + row * GRID_COLS + col;
                if (abs_idx >= 0 && abs_idx < l->filter_count) { l->selected = abs_idx; launcher_launch_selected(l, wm); }
            }
        }
        return 1;
    } else if (ev->type == ButtonPress && ev->xbutton.window != l->win) { launcher_toggle(wm); return 1; }
    return 0;
}

void launcher_destroy(WM *wm) {
    if (!g_launcher_initialized) return;
    Launcher *l = &g_launcher;
    if (l->visible) XUngrabKeyboard(wm->dpy, CurrentTime);
    for (int i = 0; i < l->app_count; i++) if (l->apps[i].icon_surf) cairo_surface_destroy(l->apps[i].icon_surf);
    XFreePixmap(wm->dpy, l->buffer); XFreeGC(wm->dpy, l->gc); XDestroyWindow(wm->dpy, l->win); g_launcher_initialized = 0;
}
