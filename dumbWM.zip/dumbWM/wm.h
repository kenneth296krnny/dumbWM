#ifndef WM_H
#define WM_H

#include <X11/Xlib.h>
#include <X11/keysym.h>
#include <X11/Xatom.h>
#include "bsp.h"
#include "config.h"

#define MAX_WS MAX_WORKSPACES

typedef struct WM {
    Display     *dpy;
    Window       root;
    int          screen;
    int          screen_w, screen_h;

    /* Workspaces: each has its own BSP tree */
    BspNode     *ws_trees[MAX_WS];
    int          current_ws;

    /* Client list (all workspaces) */
    Client      *clients;
    Client      *focused;
    Client      *scratchpad;

    Config      *cfg;
    int          running;
    char         config_path[512];
    int          meta_pressed;  /* For Super-only launcher toggle */

    /* Atoms */
    Atom         wm_protocols;
    Atom         wm_delete;
    Atom         net_wm_name;
    Atom         net_active_window;
} WM;

/* Core lifecycle */
void wm_init(WM *wm, Config *cfg);
void wm_run(WM *wm);
void wm_cleanup(WM *wm);

/* Client management */
Client *wm_client_add(WM *wm, Window win);
void    wm_client_remove(WM *wm, Client *c);
Client *wm_client_find(WM *wm, Window win);
void    wm_focus_client(WM *wm, Client *c);
void    wm_kill_client(WM *wm, Client *c);

/* Layout */
void wm_tile(WM *wm);
void wm_workspace_switch(WM *wm, int ws);

/* Spawn */
void wm_spawn(const char *cmd);

/* Config reload */
void wm_reload_config(WM *wm);

#endif /* WM_H */
