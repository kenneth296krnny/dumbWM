#ifndef BAR_H
#define BAR_H

#include <X11/Xlib.h>

/* WM is defined in wm.h; we only need a pointer here */
struct WM_State;

typedef struct {
    Window   win;
    GC       gc;
    Pixmap   buffer;    /* Double buffering */
    int      x, y, w, h;
    XFontStruct *font;
} Bar;

/* Use the real WM type since callers always include wm.h first */
#include "wm.h"

/* Lifecycle */
void bar_init(Bar *bar, WM *wm);
void bar_update(WM *wm);
void bar_destroy(Bar *bar, WM *wm);
void bar_handle_click(WM *wm, int x, int y);
void bar_reload_colors(WM *wm);  /* Re-read GTK theme colors if follow mode on */

#endif /* BAR_H */
